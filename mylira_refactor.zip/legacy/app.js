const { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } = React;
const IconTrash = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "28", height: "28", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("path", { d: "M3 6h18" }),
    React.createElement("path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" }),
    React.createElement("path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" }),
    React.createElement("line", { x1: "10", x2: "10", y1: "11", y2: "17" }),
    React.createElement("line", { x1: "14", x2: "14", y1: "11", y2: "17" })));
const IconCheck = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "48", height: "48", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round", className: "text-emerald-500" },
    React.createElement("polyline", { points: "20 6 9 17 4 12" })));
const IconWarn = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "48", height: "48", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round", className: "text-red-500" },
    React.createElement("circle", { cx: "12", cy: "12", r: "10" }),
    React.createElement("line", { x1: "12", y1: "8", x2: "12", y2: "12" }),
    React.createElement("line", { x1: "12", y1: "16", x2: "12.01", y2: "16" })));
const IconInfo = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "48", height: "48", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round", className: "text-blue-500" },
    React.createElement("circle", { cx: "12", cy: "12", r: "10" }),
    React.createElement("line", { x1: "12", y1: "16", x2: "12", y2: "12" }),
    React.createElement("line", { x1: "12", y1: "8", x2: "12.01", y2: "8" })));
const IconChevronDown = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("polyline", { points: "6 9 12 15 18 9" })));
const IconBulbSmall = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("path", { d: "M9 18h6" }),
    React.createElement("path", { d: "M10 22h4" }),
    React.createElement("path", { d: "M12 2v1" }),
    React.createElement("path", { d: "M12 14h.01" }),
    React.createElement("path", { d: "M22 12c0-5.5-4.5-10-10-10S2 6.5 2 12a10 10 0 0 0 2.2 6.3c.6.8.8 1.7.8 2.7 0 2.2 2.2 3 5 3h4c2.8 0 5-.8 5-3 0-1 .2-1.9.8-2.7A10 10 0 0 0 22 12z" })));
const IconShareIOS = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", className: "text-blue-600" },
    React.createElement("path", { d: "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" }),
    React.createElement("polyline", { points: "16 6 12 2 8 6" }),
    React.createElement("line", { x1: "12", y1: "2", x2: "12", y2: "15" })));
const IconPlusBox = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", className: "text-slate-600" },
    React.createElement("rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", ry: "2" }),
    React.createElement("line", { x1: "12", y1: "8", x2: "12", y2: "16" }),
    React.createElement("line", { x1: "8", y1: "12", x2: "16", y2: "12" })));
const IconDotsAndroid = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", className: "text-slate-600" },
    React.createElement("circle", { cx: "12", cy: "12", r: "1" }),
    React.createElement("circle", { cx: "12", cy: "5", r: "1" }),
    React.createElement("circle", { cx: "12", cy: "19", r: "1" })));
const IconClose = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
    React.createElement("line", { x1: "6", y1: "6", x2: "18", y2: "18" })));
const IconCopy = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("rect", { x: "9", y: "9", width: "13", height: "13", rx: "2", ry: "2" }),
    React.createElement("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })));
const IconHand = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "28", height: "28", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("path", { d: "M18 11V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0" }),
    React.createElement("path", { d: "M14 10V4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v2" }),
    React.createElement("path", { d: "M10 10.5V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v8" }),
    React.createElement("path", { d: "M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15" })));
const IconArrowRight = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("line", { x1: "5", y1: "12", x2: "19", y2: "12" }),
    React.createElement("polyline", { points: "12 5 19 12 12 19" })));
const IconArrowLeft = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("line", { x1: "19", y1: "12", x2: "5", y2: "12" }),
    React.createElement("polyline", { points: "12 19 5 12 12 5" })));
const IconIdea = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "28", height: "28", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", className: "text-amber-400" },
    React.createElement("path", { d: "M9 18h6" }),
    React.createElement("path", { d: "M10 22h4" }),
    React.createElement("path", { d: "M12 2v1" }),
    React.createElement("path", { d: "M12 14h.01" }),
    React.createElement("path", { d: "M22 12c0-5.5-4.5-10-10-10S2 6.5 2 12a10 10 0 0 0 2.2 6.3c.6.8.8 1.7.8 2.7 0 2.2 2.2 3 5 3h4c2.8 0 5-.8 5-3 0-1 .2-1.9.8-2.7A10 10 0 0 0 22 12z" })));
const IconArrowUp = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("line", { x1: "12", y1: "19", x2: "12", y2: "5" }),
    React.createElement("polyline", { points: "5 12 12 5 19 12" })));
const IconWhatsapp = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", className: "text-emerald-500" },
    React.createElement("path", { d: "M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" })));
const IconInstagram = () => (React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", className: "text-pink-600" },
    React.createElement("rect", { x: "2", y: "2", width: "20", height: "20", rx: "5", ry: "5" }),
    React.createElement("path", { d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" }),
    React.createElement("line", { x1: "17.5", y1: "6.5", x2: "17.51", y2: "6.5" })));
const RATE = 100;
const DENOMS_NEW_CONVERTER = [{ v: 500, s: '🌾', n: { ar: 'سنابل', en: 'Wheat' } }, { v: 200, s: '🫒', n: { ar: 'زيتون', en: 'Olive' } }, { v: 100, s: '☁️', n: { ar: 'قطن', en: 'Cotton' } }, { v: 50, s: '🍊', n: { ar: 'حمضيات', en: 'Citrus' } }, { v: 25, s: '🍇', n: { ar: 'توت', en: 'Mulberry' } }, { v: 10, s: '🌼', n: { ar: 'ياسمين', en: 'Jasmine' } }];
const DENOMS_OLD_CONVERTER = [{ v: 5000, s: '💶', n: { ar: 'خمسة آلاف', en: '5000' } }, { v: 2000, s: '💶', n: { ar: 'ألفين', en: '2000' } }, { v: 1000, s: '💵', n: { ar: 'ألف', en: '1000' } }, { v: 500, s: '💵', n: { ar: 'خمسمئة', en: '500' } }];
const DENOMS_NEW_VALS_ONLY = DENOMS_NEW_CONVERTER.map(d => d.v);
const DENOMS_OLD_VALS_ONLY = DENOMS_OLD_CONVERTER.map(d => d.v);
const DENOMS_NEW_CHANGE = [500, 200, 100, 50, 25, 20, 10];
const DENOMS_OLD_CHANGE = [5000, 2000, 1000, 500, 200];
const PRIMARY_CODES = ["USD", "AED"];
const SECONDARY_CODES = ["SAR", "EUR", "KWD", "SEK", "GBP", "JOD"];
const FLAG_BY_CODE = { USD: "🇺🇸", AED: "🇦🇪", SAR: "🇸🇦", EUR: "🇪🇺", KWD: "🇰🇼", SEK: "🇸🇪", GBP: "🇬🇧", JOD: "🇯🇴" };
const CURRENCY_DETAILS = {
    USD: { ar: "دولار أمريكي", en: "US Dollar" },
    AED: { ar: "درهم إماراتي", en: "UAE Dirham" },
    SAR: { ar: "ريال سعودي", en: "Saudi Riyal" },
    EUR: { ar: "يورو", en: "Euro" },
    KWD: { ar: "دينار كويتي", en: "Kuwaiti Dinar" },
    SEK: { ar: "كرون سويدي", en: "Swedish Krona" },
    GBP: { ar: "جنيه إسترليني", en: "British Pound" },
    JOD: { ar: "دينار أردني", en: "Jordanian Dinar" }
};
const TEXTS = {
    ar: {
        title: "لَيْرَتي",
        tab1: "الحاسبة الذكية",
        tab2: "حساب الكاش والباقي",
        tab3: "حاسبة الكهرباء",
        convertFrom: "تحويل من", old: "قديم", new: "جديد",
        toggleOldToNew: "قديم ← جديد", toggleNewToOld: "جديد ← قديم",
        inputLabel: (m) => `أدخل المبلغ (${m === 'oldToNew' ? 'قديم' : 'جديد'})`,
        resultLabel: (m) => `النتيجة (${m === 'oldToNew' ? 'جديد' : 'قديم'})`,
        fxTitle: "حاسبة العملات الأجنبية",
        breakdownTitle: "توزيع الفئات النقدية (الخيار الأنسب)",
        placeholder: "0", emptyBreakdown: "أدخل مبلغاً لعرض التوزيع..",
        leftoverMsg: (v, p) => `بقي ${v} ليرة جديدة، تدفع بقيمة ${p} ل.س قديمة.`,
        leftoverMsgOld: (v, p) => `بقي ${v} ل.س قديمة، تدفع بقيمة ${p} ليرة جديدة.`,
        billTitle: "المبلغ المطلوب (الفاتورة)", paidTitle: "المبلغ المدفوع (الكاش)",
        billNewPh: "0 جديد", billOldPh: "0 قديم", paidNewPh: "0 جديد", paidOldPh: "0 قديم",
        checkStatusGood: "المبلغ كافٍ ✅", checkStatusBad: "يوجد نقص بالمبلغ ❌", checkStatusOver: "يوجد زيادة (باقي) ℹ️",
        checkDiff: "قيمة الباقي", checkDiffShort: "المبلغ المتبقي للسداد", checkTotalRec: "مجموع المقبوض",
        scenarioNew: "خيارات إرجاع الباقي (جديد)", scenarioOld: "خيارات إرجاع الباقي (قديم)",
        shortageNew: "خيارات سداد النقص (جديد)", shortageOld: "خيارات سداد النقص (قديم)",
        countWord: "عدد", liraTypeNew: "جديدة", liraTypeOld: "قديمة", enterToShow: "أدخل الفاتورة والمدفوع\nللتدقيق وحساب الباقي", opt: "خيار",
        hintNext: "التالي", hintDone: "ابدأ الآن", hintSkip: "تخطي الشرح",
        hint1Title: "حاسبة التبديل السريع",
        hint1Desc: "اضغط هنا للتبديل بين الليرة القديمة والجديدة بلمسة واحدة.",
        hint2Title: "حاسبة البائع والزبون",
        hint2Desc: "أداة تضمن حق الطرفين: أدخل قيمة الفاتورة وقيمة المبلغ المدفوع، وسيقوم التطبيق فوراً بتدقيق الحساب وعرض خيارات إرجاع الباقي.",
        hintWelcome: "أهلاً بك في ليرتي! التطبيق يعمل بالكامل بدون إنترنت.",
        installTitle: "استخدم التطبيق بدون إنترنت",
        installIOS: "اضغط", installIOS2: "ثم اختر 'إضافة إلى الصفحة الرئيسية'",
        installAndroid: "اضغط", installAndroid2: "ثم اختر 'تثبيت التطبيق' أو 'Add to Home Screen'",
        moreCurrencies: "عرض باقي العملات", lessCurrencies: "إخفاء باقي العملات",
        showExample: "مثال", exampleTitle: "مثال عملي (مختلط):",
        exampleText: "تخيل الفاتورة بالجديد: (1,750 ليرة)\nوالزبون دفع خليط: (1,000 جديد + 100,000 قديم)\nكيف يتم توحيد الحساب ومعرفة الباقي فوراً؟",
        applyExample: "تطبيق المثال",
        showOptions: "عرض خيارات توزيع أخرى", hideOptions: "إخفاء الخيارات",
        faqTitle: "أسئلة شائعة", copyQa: "نسخ السؤال والجواب", copied: "تم النسخ ✅",
        ratesTable: "نشرة أسعار الصرف", buy: "شراء", sell: "مبيع", floatingRatesBtn: "نشرة الأسعار",
        moreFaq: "عرض باقي الأسئلة", lessFaq: "إخفاء باقي الأسئلة",
        fxLabel: "القيمة بالليرة السورية", disclaimer: "تنويه: أسعار الصرف الظاهرة هي قيم تقديرية لغايات المعلومات العامة فقط، ولا تعبر عن الأسعار الرسمية. الموقع يخلي مسؤوليته عن أي قرارات مالية تعتمد على هذه البيانات.",
        developedBy: "تم التطوير في MiniAppsStudio 2026",
        buyLbl: "شراء", sellLbl: "مبيع",
        legalTitle: "إخلاء مسؤولية قانوني",
        closeLegal: "إغلاق",
        contactUs: "تواصل معنا"
    },
    en: {
        title: "MyLira - Calculator",
        tab1: "Smart Calculator",
        tab2: "Cash Calculator",
        tab3: "Electricity",
        convertFrom: "Convert from", old: "Old", new: "New",
        toggleOldToNew: "Old → New", toggleNewToOld: "New → Old",
        inputLabel: (m) => `Enter Amount (${m === 'oldToNew' ? 'Old' : 'New'})`,
        resultLabel: (m) => `Result (${m === 'oldToNew' ? 'New' : 'Old'})`,
        fxTitle: "Currency Calculator",
        breakdownTitle: "Banknote Breakdown (Best Option)", placeholder: "0", emptyBreakdown: "Enter amount to see breakdown..", leftoverMsg: (v, p) => `Remaining ${v} New Lira, pay as ${p} Old SYP.`, leftoverMsgOld: (v, p) => `Remaining ${v} Old SYP, pay as ${p} New Lira.`,
        billTitle: "Required Amount (Bill)", paidTitle: "Paid Amount (Cash)",
        billNewPh: "0 New", billOldPh: "0 Old", paidNewPh: "0 New", paidOldPh: "0 Old",
        checkStatusGood: "Exact Amount ✅", checkStatusBad: "Shortage Detected ❌", checkStatusOver: "Change Due ℹ️",
        checkDiff: "Change Amount", checkDiffShort: "Remaining to Pay", checkTotalRec: "Total Received",
        scenarioNew: "Return Options (New)", scenarioOld: "Return Options (Old)",
        shortageNew: "Payment Options for Shortage (New)", shortageOld: "Payment Options for Shortage (Old)",
        countWord: "Count", liraTypeNew: "New", liraTypeOld: "Old", enterToShow: "Enter Bill & Paid\nto check & calc change", opt: "Option",
        hintNext: "Next", hintDone: "Start Now", hintSkip: "Skip",
        hint1Title: "Quick Calculator",
        hint1Desc: "Tap here to switch between Old and New Lira instantly.",
        hint2Title: "Seller & Buyer Calc",
        hint2Desc: "Ensure accuracy for both parties: Enter the Bill and Paid amounts to instantly audit the total and see the best options for giving change.",
        hintWelcome: "Welcome to MyLira! The app works completely offline.",
        installTitle: "Use App Offline",
        installIOS: "Tap", installIOS2: "then 'Add to Home Screen'",
        installAndroid: "Tap", installAndroid2: "then 'Install App' or 'Add to Home Screen'",
        moreCurrencies: "Show more currencies", lessCurrencies: "Show less",
        showExample: "Example", exampleTitle: "Mixed Example:",
        exampleText: "Imagine the Bill is New: (1,750 New)\nAnd Customer pays mixed: (1,000 New + 100,000 Old)\nHow to combine totals and find the exact change?",
        applyExample: "Apply Example",
        showOptions: "Show other breakdown options", hideOptions: "Hide options",
        faqTitle: "Common Questions", copyQa: "Copy Q&A", copied: "Copied ✅",
        ratesTable: "Exchange Rates Table", buy: "Buy", sell: "Sell", floatingRatesBtn: "Rates List",
        moreFaq: "Show more questions", lessFaq: "Show less",
        fxLabel: "Value in Syrian Lira", disclaimer: "Disclaimer: Exchange rates shown are approximate values for general information purposes only and do not reflect official rates. The site assumes no responsibility for financial decisions based on this data.",
        developedBy: "Developed at MiniAppsStudio 2026",
        buyLbl: "Buy", sellLbl: "Sell",
        legalTitle: "Legal Disclaimer",
        closeLegal: "Close",
        contactUs: "Contact Us"
    }
};
const FAQ_DATA = [
    { q: "ايمت بلّش العمل بتبديل الليرة؟", a: "🔹 التبديل بلّش رسميًا بـ 1 كانون الثاني 2026، وبلشوا ينزلوا الليرة الجديدة عالسوق بدل القديمة." },
    { q: "شو يعني “استبدال العملة”؟", a: "🔹 يعني بس حذف صفرين من الرقم، يعني كل 100 ليرة قديمة = 1 ليرة جديدة. القيمة نفسها ما تغيّرت." },
    { q: "لازم ندفع رسوم أو عمولة لنبدّل؟", a: "🔹 لأ أبدًا. التبديل مجاني 100%، وما حدا مسموح ياخد رسوم أو ضريبة عليه." },
    { q: "ليش قرروا يغيّروا الليرة؟", a: "🔹 لحتى يصير التعامل أسهل، الأرقام أبسط، والحساب أسرع، وكمان ليخفّفوا كمية الورق المتداول بين الناس." },
    { q: "قديش مدة التبديل والتعايش بين العملتين؟", a: "🔹 في فترة انتقالية حوالي 90 يوم ممكن تنمدّد، وفيها بتقدر تدفع بالقديمة والجديدة سوا." },
    { q: "شو هي أول الفئات الجديدة اللي نزلت؟", a: "🔹 بلش التداول بـ 10، 25، 50، 100، 200 و500 ليرة جديدة." },
    { q: "وفي فئات تانية جاية؟", a: "🔹 أي نعم. مخطط ينزلوا 1 ليرة، 5 ليرات، وفئة 1000 ليرة جديدة بتصميم آمن أقوى." },
    { q: "وين بقدر بدّل الليرات القديمة بالجديدة؟", a: "🔹 التبديل بيصير عبر مراكز ومؤسسات مالية معتمدة بكل المحافظات السورية." },
    { q: "هالتبديل بيأثر على سعر الصرف؟", a: "🔹 لأ أبدًا. ما له علاقة بسعر الصرف لا بالدولار ولا بغيره، وما بغيّر وضع السوق." },
    { q: "فيني استعمل القديمة والجديدة مع بعض؟", a: "🔹 إي خلال الفترة الانتقالية، مقبول الدفع بالاتنين." },
    { q: "حساباتي بالبنك شو بيصير فيها؟", a: "🔹 بتتحوّل تلقائيًا للرقم الجديد بدون ما تعمل أي شي أو تروح عالمصرف." },
    { q: "نزلت الليرات الجديدة عالسوق ولا لسه؟", a: "🔹 إي نعم، صار في ضخ للفئات الجديدة وبصير التداول فيها تدريجياً." },
    { q: "بعد الـ90 يوم، فيني لسه بدّل؟", a: "🔹 إي، بس بعد هالفترة بيصير مصرف سوريا المركزي هو الجهة الوحيدة للتبديل، والعملية ممكن تضل سنين لتغطية كل الكمية." },
    { q: "في شروط أو أوراق مطلوبة للتبديل؟", a: "🔹 غالبًا بيطلبوا إثبات هوية أو إجراءات بسيطة حسب المركز، بس التبديل نفسه مجاني ومنظّم." },
    { q: "هل تغيّر سعر الصرف بسبب الأداة؟", a: "🔹 لأ. هي بس بتحوّل الرقم من كبير لصغير، القيمة نفسها." },
    { q: "هل الأسعار نزلت؟", a: "🔹 لأ. ما تغيّر شي بالسعر الحقيقي، بس شكل الرقم هو اللي صغر." },
    { q: "وين راح الفرق؟", a: "🔹 ما راح شي. القيمة هي هي، بس بدل ما نقول 1000 صار الرقم 10." },
    { q: "الرواتب والإيجارات نقصت؟", a: "🔹 لأ أبداً. كلشي بينقص صفرين بدون ما تخسر ولا ليرة بقيمتها." },
    { q: "لازم نحول فوراً؟", a: "🔹 مو ضرورة، في فترة نتعايش فيها بين الرقمين لحد ما نتعود." },
    { q: "كيف أحسب بسرعة؟", a: "🔹 سهل كتير: احذف صفرين\nكل 100 قديمة = 1 جديدة\nوإذا لخبطت، فيك تستخدم حاسبة." }
];
const getScenarios = (target, denoms, maxCount = 4) => {
    const solutions = [];
    const startTime = performance.now();
    function solve(remaining, idx, currentProfile) {
        if (solutions.length >= maxCount || (performance.now() - startTime > 15))
            return;
        if (remaining === 0) {
            solutions.push(currentProfile);
            return;
        }
        if (idx >= denoms.length)
            return;
        const coin = denoms[idx];
        const maxUse = Math.floor(remaining / coin);
        let countsToTry = [];
        countsToTry.push(maxUse);
        if (maxUse > 0)
            countsToTry.push(maxUse - 1);
        if (maxUse > 1)
            countsToTry.push(0);
        countsToTry = [...new Set(countsToTry)];
        for (let count of countsToTry) {
            if (solutions.length >= maxCount)
                break;
            const newProfile = { ...currentProfile };
            if (count > 0)
                newProfile[coin] = count;
            solve(remaining - (count * coin), idx + 1, newProfile);
        }
    }
    solve(Math.round(target), 0, {});
    return solutions.map(sol => Object.entries(sol).map(([val, count]) => ({ val: parseInt(val), count })).sort((a, b) => b.val - a.val));
};
const InstallBanner = ({ t, isAr }) => {
    const [show, setShow] = useState(false);
    const [os, setOs] = useState(null);
    useEffect(() => {
        const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
        if (isStandalone)
            return;
        const isClosed = localStorage.getItem('mylira_install_banner_closed_v1');
        if (isClosed)
            return;
        const ua = navigator.userAgent || navigator.vendor || window.opera;
        if (/iPad|iPhone|iPod/.test(ua) && !window.MSStream) {
            setOs('ios');
            setShow(true);
        }
        else if (/android/i.test(ua)) {
            setOs('android');
            setShow(true);
        }
    }, []);
    const handleClose = () => { setShow(false); localStorage.setItem('mylira_install_banner_closed_v1', 'true'); };
    if (!show)
        return null;
    return (React.createElement("div", { className: "fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-[0_-4px_20px_rgba(0,0,0,0.1)] p-4 pb-6 animate-fade-in safe-area-bottom md:max-w-md md:left-1/2 md:-translate-x-1/2 rounded-t-2xl" },
        React.createElement("div", { className: "max-w-md mx-auto relative pr-8" },
            React.createElement("button", { onClick: handleClose, type: "button", "aria-label": (isAr ? "إغلاق" : "Close"), className: "absolute -top-1 -right-2 p-2 text-slate-400 hover:text-red-500" },
                React.createElement(IconClose, null)),
            React.createElement("div", { className: "flex items-center gap-3 mb-2" },
                React.createElement("span", { className: "text-2xl" }, "\uD83D\uDCF2"),
                React.createElement("h3", { className: "font-black text-sm text-slate-800" }, t.installTitle)),
            React.createElement("div", { className: "text-xs font-bold text-slate-600 leading-relaxed flex flex-wrap items-center gap-1" }, os === 'ios' ? (React.createElement(React.Fragment, null,
                React.createElement("span", null, t.installIOS),
                React.createElement("span", { className: "inline-flex items-center justify-center w-6 h-6 bg-slate-100 rounded border border-slate-200 mx-0.5" },
                    React.createElement(IconShareIOS, null)),
                React.createElement("span", null, t.installIOS2),
                React.createElement("span", { className: "inline-flex items-center justify-center w-6 h-6 bg-slate-100 rounded border border-slate-200 mx-0.5" },
                    React.createElement(IconPlusBox, null)))) : (React.createElement(React.Fragment, null,
                React.createElement("span", null, t.installAndroid),
                React.createElement("span", { className: "inline-flex items-center justify-center w-6 h-6 bg-slate-100 rounded border border-slate-200 mx-0.5" },
                    React.createElement(IconDotsAndroid, null)),
                React.createElement("span", null, t.installAndroid2)))))));
};
const ScrollToTop = ({ isAr }) => {
    const [visible, setVisible] = useState(false);
    useEffect(() => {
        const toggleVisibility = () => { if (window.pageYOffset > 300)
            setVisible(true);
        else
            setVisible(false); };
        window.addEventListener('scroll', toggleVisibility);
        return () => window.removeEventListener('scroll', toggleVisibility);
    }, []);
    const scrollToTop = () => { window.scrollTo({ top: 0, behavior: 'smooth' }); };
    if (!visible)
        return null;
    return (React.createElement("button", { onClick: scrollToTop, className: `fixed bottom-24 ${isAr ? 'left-6' : 'right-6'} z-40 bg-indigo-600/90 backdrop-blur text-white w-12 h-12 flex items-center justify-center rounded-full shadow-lg shadow-indigo-600/30 hover:bg-indigo-700 transition-all active:scale-95 animate-scale-up md:right-[calc(50%-350px)] lg:right-[calc(50%-480px)]`, "aria-label": "Back to top" },
        React.createElement(IconArrowUp, null)));
};
const SmartHints = ({ step, onNext, onSkip, t, isAr }) => {
    const [pos, setPos] = useState(null);
    useEffect(() => { if (step > 0)
        document.body.classList.add('no-scroll');
    else
        document.body.classList.remove('no-scroll'); return () => document.body.classList.remove('no-scroll'); }, [step]);
    useLayoutEffect(() => {
        const calculatePos = () => {
            let targetId = '';
            if (step === 1)
                targetId = 'toggle-container';
            if (step === 2)
                targetId = 'tab-btn-change';
            if (targetId) {
                const el = document.getElementById(targetId);
                if (el) {
                    const rect = el.getBoundingClientRect();
                    setPos({ top: rect.top, left: rect.left, width: rect.width, height: rect.height, bottom: rect.bottom });
                }
            }
            else {
                setPos(null);
            }
        };
        calculatePos();
        window.addEventListener('resize', calculatePos);
        return () => window.removeEventListener('resize', calculatePos);
    }, [step]);
    if (step === 0 || !pos)
        return null;
    const cardStyle = { top: pos.bottom + 25, left: isAr ? 'auto' : Math.min(Math.max(10, pos.left), window.innerWidth - 300), right: isAr ? Math.min(Math.max(10, window.innerWidth - (pos.left + pos.width) - 20), window.innerWidth - 300) : 'auto', width: '280px' };
    if (!isAr)
        cardStyle.left = Math.max(10, Math.min(window.innerWidth - 290, pos.left + (pos.width / 2) - 140));
    if (isAr)
        cardStyle.right = Math.max(10, Math.min(window.innerWidth - 290, (window.innerWidth - pos.left - pos.width) + (pos.width / 2) - 140));
    const arrowLeft = pos.left + (pos.width / 2);
    return (React.createElement("div", { className: "fixed inset-0 z-[100] bg-transparent transition-all duration-300 pointer-events-auto" },
        React.createElement("div", { className: "absolute bg-transparent border-[4px] border-indigo-500 rounded-2xl transition-all duration-300 highlight-pulse pointer-events-none", style: { top: pos.top - 6, left: pos.left - 6, width: pos.width + 12, height: pos.height + 12, boxShadow: '0 0 0 9999px rgba(0,0,0,0)' } }),
        React.createElement("div", { className: "absolute bg-white p-6 rounded-3xl shadow-[0_10px_60px_-15px_rgba(0,0,0,0.3)] animate-fade-in border border-indigo-100 pointer-events-auto", style: cardStyle },
            React.createElement("div", { className: "flex justify-between items-start mb-3" },
                React.createElement("div", { className: "flex items-center gap-3" },
                    step === 1 ? React.createElement(IconIdea, null) : React.createElement("span", { className: "text-2xl" }, "\uD83E\uDD1D"),
                    React.createElement("span", { className: `font-black text-lg ${step === 1 ? 'text-indigo-600' : 'text-blue-600'}` }, step === 1 ? t.hint1Title : t.hint2Title)),
                React.createElement("button", { onClick: onSkip, className: "text-xs font-bold text-slate-400 hover:text-red-500 transition-colors bg-slate-100 px-3 py-1.5 rounded-full" }, t.hintSkip)),
            React.createElement("p", { className: "text-base text-slate-700 font-bold mb-6 leading-relaxed" }, step === 1 ? t.hint1Desc : t.hint2Desc),
            React.createElement("div", { className: "absolute -top-3 w-6 h-6 bg-white rotate-45 border-t border-l border-indigo-100", style: { left: !isAr ? arrowLeft - parseInt(cardStyle.left) - 10 : 'auto', right: isAr ? (window.innerWidth - arrowLeft) - parseInt(cardStyle.right) - 10 : 'auto' } }),
            React.createElement("button", { onClick: onNext, className: `w-full py-3 text-white rounded-2xl font-black text-sm shadow-xl ${step === 1 ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/30' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/30'}` }, step === 2 ? t.hintDone : t.hintNext))));
};
const Footer = ({ t }) => (React.createElement("div", { className: "pt-6 border-t border-slate-200 mt-6 text-center pb-8 px-4" },
    React.createElement("h4", { className: "text-sm font-black text-slate-600 mb-4" }, t.contactUs),
    React.createElement("div", { className: "flex justify-center gap-6 mb-6" },
        React.createElement("a", { href: "https://wa.me/963993995261", target: "_blank", rel: "noopener noreferrer", "aria-label": "WhatsApp", className: "p-3 bg-emerald-50 text-emerald-600 rounded-full hover:bg-emerald-100 transition shadow-sm" },
            React.createElement(IconWhatsapp, null)),
        React.createElement("a", { href: "", target: "_blank", rel: "noopener noreferrer", "aria-label": "Instagram", className: "p-3 bg-pink-50 text-pink-600 rounded-full hover:bg-pink-100 transition shadow-sm" },
            React.createElement(IconInstagram, null))),
    React.createElement("p", { className: "text-sm font-black text-slate-500 uppercase tracking-widest" }, t.developedBy)));
const FaqCard = ({ item, t }) => {
    const [copied, setCopied] = useState(false);
    const handleCopy = () => {
        const text = `${item.q}\n${item.a}`;
        navigator.clipboard.writeText(text).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); });
    };
    return (React.createElement("div", { className: "app-card p-5 border border-slate-100 shadow-sm" },
        React.createElement("h4", { className: "font-black text-slate-800 text-lg mb-2 leading-relaxed" }, item.q),
        React.createElement("p", { className: "text-base font-bold text-slate-700 leading-relaxed whitespace-pre-line mb-4" }, item.a),
        React.createElement("button", { onClick: handleCopy, className: `w-full py-2.5 px-4 rounded-xl text-sm font-black flex items-center justify-center gap-2 transition-all ${copied ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'}` }, copied ? React.createElement("span", null, t.copied) : React.createElement(React.Fragment, null,
            React.createElement(IconCopy, null),
            React.createElement("span", null, t.copyQa)))));
};
const SmartConverter = ({ lang, t, rates }) => {
    const [val, setVal] = useState('');
    const [mode, setMode] = useState('oldToNew');
    const [showMore, setShowMore] = useState(false);
    const [showMoreOptions, setShowMoreOptions] = useState(false);
    const [showAllFaq, setShowAllFaq] = useState(false);
    const [showLegal, setShowLegal] = useState(false);
    const [showTickerHint, setShowTickerHint] = useState(true);
    const tickerRef = useRef(null);
    const animationFrameRef = useRef(null);
    const isAutoScrolling = useRef(true);
    const handleTickerInteraction = () => {
        if (isAutoScrolling.current) {
            isAutoScrolling.current = false;
            setShowTickerHint(false);
            if (animationFrameRef.current)
                cancelAnimationFrame(animationFrameRef.current);
        }
    };
    const handleWheel = (e) => { if (tickerRef.current) {
        tickerRef.current.scrollLeft += e.deltaY;
        handleTickerInteraction();
    } };
    useEffect(() => {
        const scrollContainer = tickerRef.current;
        if (!scrollContainer)
            return;
        const animate = () => {
            if (!isAutoScrolling.current)
                return;
            scrollContainer.scrollLeft += 0.5;
            if (scrollContainer.scrollLeft >= (scrollContainer.scrollWidth - scrollContainer.clientWidth - 1)) {
                scrollContainer.scrollLeft = 0;
            }
            animationFrameRef.current = requestAnimationFrame(animate);
        };
        animationFrameRef.current = requestAnimationFrame(animate);
        return () => { if (animationFrameRef.current)
            cancelAnimationFrame(animationFrameRef.current); };
    }, []);
    const inputRef = useRef(null);
    const isAr = lang === 'ar';
    const toggleMode = (newMode) => { if (newMode !== mode) {
        setMode(newMode);
        setVal('');
        setShowMoreOptions(false);
        if (inputRef.current)
            inputRef.current.focus();
    } };
    const cleanInput = (txt) => { const normalized = txt.replace(/[٠-٩]/g, d => "0123456789"["٠١٢٣٤٥٦٧٨٩".indexOf(d)] || d); return normalized.replace(/[^0-9.]/g, ''); };
    const num = parseFloat(cleanInput(val)) || 0;
    const convertedVal = mode === 'oldToNew' ? (num / RATE) : (num * RATE);
    const baseForCurrency = mode === 'oldToNew' ? convertedVal : convertedVal;
    const formatRes = (val) => { if (!val || isNaN(val) || val === 0)
        return "0"; return val.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 }); };
    const breakdown = useMemo(() => {
        let current = convertedVal;
        const denoms = mode === 'oldToNew' ? DENOMS_NEW_CONVERTER : DENOMS_OLD_CONVERTER;
        const res = [];
        if (current > 0) {
            denoms.forEach(d => {
                const count = Math.floor(current / d.v);
                if (count > 0) {
                    res.push({ ...d, count });
                    current = Math.round((current - count * d.v) * 100) / 100;
                }
            });
        }
        return { list: res, rem: current };
    }, [num, mode, convertedVal]);
    const alternativeScenarios = useMemo(() => {
        if (breakdown.list.length === 0)
            return [];
        const denomsVals = mode === 'oldToNew' ? DENOMS_NEW_VALS_ONLY : DENOMS_OLD_VALS_ONLY;
        const distributedAmount = breakdown.list.reduce((acc, item) => acc + (item.v * item.count), 0);
        if (distributedAmount <= 0)
            return [];
        const allScenarios = getScenarios(distributedAmount, denomsVals, 6);
        const option1Str = JSON.stringify(breakdown.list.map(i => ({ val: i.v, count: i.count })).sort((a, b) => b.val - a.val));
        return allScenarios.filter(scen => {
            const scenStr = JSON.stringify(scen.map(i => ({ val: i.val, count: i.count })).sort((a, b) => b.val - a.val));
            return scenStr !== option1Str;
        });
    }, [breakdown, mode]);
    const tickerItems = [...PRIMARY_CODES, ...SECONDARY_CODES].map(code => {
        var _a, _b, _c, _d;
        const rateBuy = ((_a = rates[code]) === null || _a === void 0 ? void 0 : _a.buy) || ((_b = rates[code]) === null || _b === void 0 ? void 0 : _b.mid);
        const rateSell = ((_c = rates[code]) === null || _c === void 0 ? void 0 : _c.sell) || ((_d = rates[code]) === null || _d === void 0 ? void 0 : _d.mid);
        return { code, flag: FLAG_BY_CODE[code], buy: rateBuy, sell: rateSell };
    }).filter(i => i.buy);
    return (React.createElement("div", { className: "app-container-wrapper" },
        React.createElement("div", { id: "toggle-container", className: "bg-slate-200/80 p-1.5 rounded-2xl mx-1 relative z-20 flex font-black text-sm mt-4" },
            React.createElement("button", { onClick: () => toggleMode('oldToNew'), className: `flex-1 py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all duration-300 ${mode === 'oldToNew' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}` },
                isAr ? React.createElement(IconArrowLeft, null) : React.createElement(IconArrowRight, null),
                React.createElement("span", null, t.toggleOldToNew)),
            React.createElement("button", { onClick: () => toggleMode('newToOld'), className: `flex-1 py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all duration-300 ${mode === 'newToOld' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}` },
                isAr ? React.createElement(IconArrowLeft, null) : React.createElement(IconArrowRight, null),
                React.createElement("span", null, t.toggleNewToOld))),
        React.createElement("div", { className: "app-card p-6 shadow-sm border border-black/5 relative z-0 mx-4 mt-4" },
            React.createElement("div", { className: "text-base font-black text-slate-600 uppercase mb-2 tracking-widest" }, t.inputLabel(mode)),
            React.createElement("input", { ref: inputRef, type: "text", dir: "ltr", inputMode: "decimal", value: val, onChange: (e) => { setVal(cleanInput(e.target.value)); setShowMoreOptions(false); }, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.placeholder, className: `input-field text-indigo-950 ${isAr ? 'text-right' : 'text-left'}` }),
            React.createElement("div", { className: "mt-6 pt-5 border-t border-black/5" },
                React.createElement("div", { className: "text-base font-black text-slate-600 uppercase mb-2 tracking-widest" }, t.resultLabel(mode)),
                React.createElement("div", { className: "text-5xl font-black text-indigo-600" }, convertedVal.toLocaleString(isAr ? 'ar-SY' : 'en-US', { maximumFractionDigits: 2 })))),
        breakdown.rem > 0 && (React.createElement("div", { className: "mx-4 mt-4 p-4 bg-amber-50 rounded-2xl border border-amber-100 flex gap-3 items-start animate-pulse" },
            React.createElement("span", { className: "text-2xl" }, "\u26A0\uFE0F"),
            React.createElement("div", { className: "text-amber-900 text-sm font-bold leading-relaxed" }, mode === 'oldToNew' ? t.leftoverMsg(breakdown.rem, Math.round(breakdown.rem * RATE).toLocaleString()) : t.leftoverMsgOld(breakdown.rem, (breakdown.rem / RATE).toFixed(2))))),
        React.createElement("div", { className: "space-y-3 px-4 mt-4" },
            React.createElement("h3", { className: "text-sm font-black text-slate-600 px-2 uppercase tracking-widest" }, t.breakdownTitle),
            React.createElement("div", { className: "space-y-2" }, breakdown.list.length > 0 ? breakdown.list.map(b => (React.createElement("div", { key: b.v, className: "app-card p-4 flex items-center justify-between border border-black/5 shadow-sm" },
                React.createElement("div", { className: "flex items-center gap-4" },
                    React.createElement("span", { className: "text-4xl" }, b.s),
                    React.createElement("div", null,
                        React.createElement("div", { className: "font-black text-2xl leading-none text-slate-800" }, b.v.toLocaleString()),
                        React.createElement("div", { className: "text-sm font-bold text-slate-500 mt-1" }, b.n[lang]))),
                React.createElement("div", { className: "app-button px-5 py-2 rounded-xl font-black text-xl" },
                    "\u00D7 ",
                    b.count)))) : (React.createElement("div", { className: "text-center py-6 text-slate-500 font-bold text-base italic opacity-80" }, t.emptyBreakdown)))),
        alternativeScenarios.length > 0 && (React.createElement("div", { className: "pt-2 px-4" },
            React.createElement("button", { onClick: () => setShowMoreOptions(!showMoreOptions), className: "w-full py-3.5 rounded-2xl bg-indigo-50 text-indigo-700 border border-indigo-100 font-black text-sm flex items-center justify-center gap-2 hover:bg-indigo-100 transition-colors mb-2" },
                React.createElement("span", null, showMoreOptions ? t.hideOptions : t.showOptions),
                React.createElement("span", { className: `transform transition-transform duration-300 ${showMoreOptions ? 'rotate-180' : ''}` },
                    React.createElement(IconChevronDown, null))),
            React.createElement("div", { className: `slider-content ${showMoreOptions ? 'open' : ''}` },
                React.createElement("div", { className: "space-y-3 pb-2" },
                    React.createElement("div", { className: "flex flex-wrap gap-2 items-stretch justify-center" }, alternativeScenarios.map((items, idx) => (React.createElement("div", { key: `alt-${idx}`, className: "flex-auto min-w-[140px] rounded-2xl border bg-white p-4 shadow-sm flex flex-col justify-center border-indigo-100" },
                        React.createElement("div", { className: "mb-2 flex items-center gap-2 justify-center" },
                            React.createElement("span", { className: "px-3 py-1 rounded text-xs font-black uppercase tracking-widest bg-indigo-50 text-indigo-700" },
                                t.opt,
                                " ",
                                idx + 2)),
                        React.createElement("div", { className: "flex flex-wrap gap-2 justify-center" }, items.map((item, i) => (React.createElement("div", { key: i, className: "inline-flex flex-col items-center justify-center bg-slate-50 rounded-xl py-2 px-3 border border-slate-100 min-w-[70px]" },
                            React.createElement("span", { className: "text-2xl font-black text-slate-900 tabular-nums leading-none" }, item.val),
                            React.createElement("span", { className: "text-xs font-bold mt-1 text-indigo-700" },
                                "x",
                                item.count))))))))))))),
        React.createElement("div", { className: "space-y-3 px-4 mt-4" },
            React.createElement("div", { className: "w-full bg-amber-50 border-y border-amber-100 py-2 overflow-hidden mb-2 rounded-xl" },
                React.createElement("div", { className: "animate-marquee inline-block whitespace-nowrap" },
                    React.createElement("span", { className: "text-xs font-bold text-amber-700 px-4" }, t.disclaimer))),
            React.createElement("div", { className: "flex items-center gap-2 pl-2 overflow-hidden" },
                React.createElement("h3", { className: "text-sm font-black text-slate-600 uppercase tracking-widest whitespace-nowrap" }, t.fxTitle),
                React.createElement("div", { className: "relative flex-1 overflow-hidden h-14" },
                    React.createElement("div", { ref: tickerRef, className: "flex overflow-x-auto whitespace-nowrap gap-3 custom-scrollbar h-full items-center px-1", onTouchStart: handleTickerInteraction, onMouseDown: handleTickerInteraction, onWheel: handleWheel }, tickerItems.map(item => {
                        var _a, _b;
                        return (React.createElement("div", { key: item.code, className: "flex-shrink-0 bg-white border border-slate-200 rounded-xl px-4 py-2 flex items-center gap-3 shadow-sm h-full" },
                            React.createElement("span", { className: "text-2xl" }, item.flag),
                            React.createElement("span", { className: "text-base font-black text-slate-800" }, item.code),
                            React.createElement("div", { className: "flex items-center gap-2 text-sm font-mono font-bold" },
                                React.createElement("span", { className: "text-indigo-700" }, (_a = item.buy) === null || _a === void 0 ? void 0 : _a.toFixed(0)),
                                React.createElement("span", { className: "text-slate-400" }, "/"),
                                React.createElement("span", { className: "text-indigo-500" }, (_b = item.sell) === null || _b === void 0 ? void 0 : _b.toFixed(0)))));
                    })),
                    showTickerHint && (React.createElement("div", { className: "absolute inset-0 bg-white/10 backdrop-blur-[1px] flex items-center justify-center pointer-events-none transition-opacity duration-500" },
                        React.createElement("div", { className: "animate-swipe text-slate-800 drop-shadow-md" },
                            React.createElement(IconHand, null)))))),
            React.createElement("div", { className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-3" }, PRIMARY_CODES.map(code => {
                var _a, _b, _c, _d;
                const rateBuy = ((_a = rates[code]) === null || _a === void 0 ? void 0 : _a.buy) || ((_b = rates[code]) === null || _b === void 0 ? void 0 : _b.mid);
                const rateSell = ((_c = rates[code]) === null || _c === void 0 ? void 0 : _c.sell) || ((_d = rates[code]) === null || _d === void 0 ? void 0 : _d.mid);
                const resBuy = (rateBuy && baseForCurrency > 0) ? formatRes(baseForCurrency * rateBuy) : "0";
                const resSell = (rateSell && baseForCurrency > 0) ? formatRes(baseForCurrency * rateSell) : "0";
                const buyClass = resBuy.length > 7 ? "animate-scroll-number" : "";
                const sellClass = resSell.length > 7 ? "animate-scroll-number" : "";
                return (React.createElement("div", { key: code, className: "app-card p-4 flex flex-col justify-center border border-black/5 shadow-sm" },
                    React.createElement("div", { className: "flex justify-between items-start mb-2" },
                        React.createElement("span", { className: "text-3xl filter drop-shadow-sm" }, FLAG_BY_CODE[code]),
                        React.createElement("div", { className: "flex flex-col items-end" },
                            React.createElement("span", { className: "text-base font-black text-slate-800 leading-none" }, code),
                            React.createElement("span", { className: "text-[10px] font-bold text-slate-400 mt-0.5" }, CURRENCY_DETAILS[code][lang]))),
                    React.createElement("div", { className: "flex flex-col gap-1 w-full bg-slate-50 rounded-xl p-2 border border-slate-100" },
                        React.createElement("div", { className: "flex justify-between items-center overflow-hidden" },
                            React.createElement("span", { className: "text-[10px] font-bold text-slate-400 whitespace-nowrap ml-1" }, t.buyLbl),
                            React.createElement("div", { className: "overflow-hidden w-full text-left dir-ltr" },
                                React.createElement("span", { className: `text-sm font-black text-indigo-700 font-mono ${buyClass}` }, resBuy))),
                        React.createElement("div", { className: "w-full h-px bg-slate-200" }),
                        React.createElement("div", { className: "flex justify-between items-center overflow-hidden" },
                            React.createElement("span", { className: "text-[10px] font-bold text-slate-400 whitespace-nowrap ml-1" }, t.sellLbl),
                            React.createElement("div", { className: "overflow-hidden w-full text-left dir-ltr" },
                                React.createElement("span", { className: `text-sm font-black text-emerald-600 font-mono ${sellClass}` }, resSell))))));
            })),
            React.createElement("div", { className: `slider-content ${showMore ? 'open' : ''}` },
                React.createElement("div", { className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4" }, SECONDARY_CODES.map(code => {
                    var _a, _b, _c, _d;
                    const rateBuy = ((_a = rates[code]) === null || _a === void 0 ? void 0 : _a.buy) || ((_b = rates[code]) === null || _b === void 0 ? void 0 : _b.mid);
                    const rateSell = ((_c = rates[code]) === null || _c === void 0 ? void 0 : _c.sell) || ((_d = rates[code]) === null || _d === void 0 ? void 0 : _d.mid);
                    const resBuy = (rateBuy && baseForCurrency > 0) ? formatRes(baseForCurrency * rateBuy) : "0";
                    const resSell = (rateSell && baseForCurrency > 0) ? formatRes(baseForCurrency * rateSell) : "0";
                    const buyClass = resBuy.length > 7 ? "animate-scroll-number" : "";
                    const sellClass = resSell.length > 7 ? "animate-scroll-number" : "";
                    return (React.createElement("div", { key: code, className: "app-card p-4 flex flex-col justify-center border border-black/5 shadow-sm" },
                        React.createElement("div", { className: "flex justify-between items-start mb-2" },
                            React.createElement("span", { className: "text-3xl filter drop-shadow-sm" }, FLAG_BY_CODE[code]),
                            React.createElement("div", { className: "flex flex-col items-end" },
                                React.createElement("span", { className: "text-base font-black text-slate-800 leading-none" }, code),
                                React.createElement("span", { className: "text-[10px] font-bold text-slate-400 mt-0.5" }, CURRENCY_DETAILS[code][lang]))),
                        React.createElement("div", { className: "flex flex-col gap-1 w-full bg-slate-50 rounded-xl p-2 border border-slate-100" },
                            React.createElement("div", { className: "flex justify-between items-center overflow-hidden" },
                                React.createElement("span", { className: "text-[10px] font-bold text-slate-400 whitespace-nowrap ml-1" }, t.buyLbl),
                                React.createElement("div", { className: "overflow-hidden w-full text-left dir-ltr" },
                                    React.createElement("span", { className: `text-sm font-black text-indigo-700 font-mono ${buyClass}` }, resBuy))),
                            React.createElement("div", { className: "w-full h-px bg-slate-200" }),
                            React.createElement("div", { className: "flex justify-between items-center overflow-hidden" },
                                React.createElement("span", { className: "text-[10px] font-bold text-slate-400 whitespace-nowrap ml-1" }, t.sellLbl),
                                React.createElement("div", { className: "overflow-hidden w-full text-left dir-ltr" },
                                    React.createElement("span", { className: `text-sm font-black text-emerald-600 font-mono ${sellClass}` }, resSell))))));
                }))),
            React.createElement("button", { onClick: () => setShowMore(!showMore), className: "w-full py-3.5 rounded-2xl bg-white border border-slate-200 text-slate-700 font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-50 transition-colors" },
                React.createElement("span", null, showMore ? t.lessCurrencies : t.moreCurrencies),
                React.createElement("span", { className: `transform transition-transform duration-300 ${showMore ? 'rotate-180' : ''}` },
                    React.createElement(IconChevronDown, null)))),
        React.createElement("div", { className: "px-4 mt-4" },
            React.createElement("button", { onClick: () => setShowLegal(!showLegal), className: "w-full py-3 rounded-xl bg-amber-50 border border-amber-100 text-amber-700 font-black text-xs flex items-center justify-center gap-2 hover:bg-amber-100 transition-colors shadow-sm" },
                React.createElement("span", null, t.legalTitle),
                React.createElement("span", { className: `transform transition-transform duration-300 ${showLegal ? 'rotate-180' : ''}` },
                    React.createElement(IconChevronDown, null))),
            React.createElement("div", { className: `slider-content ${showLegal ? 'open' : ''}` },
                React.createElement("div", { className: "mt-2 p-4 bg-white rounded-2xl text-right border border-slate-200 shadow-sm" },
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-600 mb-2 font-bold" }, "\u0625\u062E\u0644\u0627\u0621 \u0645\u0633\u0624\u0648\u0644\u064A\u0629 \u0642\u0627\u0646\u0648\u0646\u064A:"),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u062A\u0637\u0628\u064A\u0642 \u00AB\u0644\u064E\u064A\u0652\u0631\u064E\u062A\u064A \u2013 MyLira\u00BB \u0647\u0648 \u0623\u062F\u0627\u0629 \u0645\u0628\u0633\u0651\u0637\u0629 \u0644\u0644\u0645\u0633\u0627\u0639\u062F\u0629 \u0641\u064A \u062A\u062D\u0648\u064A\u0644 \u0627\u0644\u0642\u064A\u0645 \u0628\u064A\u0646 \u0627\u0644\u0644\u064A\u0631\u0629 \u0627\u0644\u0633\u0648\u0631\u064A\u0629 \u0627\u0644\u0642\u062F\u064A\u0645\u0629 \u0648\u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0648\u062A\u0633\u0647\u064A\u0644 \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A \u0627\u0644\u064A\u0648\u0645\u064A\u0629 \u0641\u0642\u0637\u060C \u0648\u0644\u0627 \u064A\u064F\u0639\u062F \u0645\u0631\u062C\u0639\u0627\u064B \u0631\u0633\u0645\u064A\u0627\u064B \u0644\u0623\u064A \u062C\u0647\u0629 \u062D\u0643\u0648\u0645\u064A\u0629 \u0623\u0648 \u0645\u0635\u0631\u0641\u064A\u0629."),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0635\u0631\u0641 \u0627\u0644\u0638\u0627\u0647\u0631\u0629 (\u0625\u0646 \u0648\u064F\u062C\u062F\u062A) \u0647\u064A \u0642\u064A\u0645 \u062A\u0642\u062F\u064A\u0631\u064A\u0629 \u0644\u063A\u0627\u064A\u0627\u062A \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0639\u0627\u0645\u0629 \u0641\u0642\u0637\u060C \u0648\u062A\u064F\u062C\u0644\u0628 \u0622\u0644\u064A\u0627\u064B \u0645\u0646 \u0645\u0635\u0627\u062F\u0631 \u062E\u0627\u0631\u062C\u064A\u0629\u060C \u0648\u0644\u0627 \u062A\u0639\u0628\u0651\u0631 \u0628\u0627\u0644\u0636\u0631\u0648\u0631\u0629 \u0639\u0646 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0631\u0633\u0645\u064A\u0629 \u0627\u0644\u0635\u0627\u062F\u0631\u0629 \u0639\u0646 \u0645\u0635\u0631\u0641 \u0633\u0648\u0631\u064A\u0629 \u0627\u0644\u0645\u0631\u0643\u0632\u064A \u0623\u0648 \u0623\u064A \u062C\u0647\u0629 \u0645\u0639\u062A\u0645\u062F\u0629\u060C \u0648\u0644\u0627 \u064A\u064F\u0636\u0645\u0646 \u062F\u0642\u062A\u0647\u0627 \u0623\u0648 \u062A\u0648\u0642\u064A\u062A \u062A\u062D\u062F\u064A\u062B\u0647\u0627."),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u0644\u0627 \u064A\u064F\u0634\u0643\u0651\u0644 \u0623\u064A \u0645\u062D\u062A\u0648\u0649 \u0645\u0627\u0644\u064A \u0623\u0648 \u0633\u0639\u0631\u064A \u0636\u0645\u0646 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639 \u0646\u0635\u064A\u062D\u0629 \u0627\u0633\u062A\u062B\u0645\u0627\u0631\u064A\u0629 \u0623\u0648 \u0645\u0627\u0644\u064A\u0629 \u0623\u0648 \u0645\u0635\u0631\u0641\u064A\u0629\u060C \u0648\u0644\u0627 \u064A\u062C\u0628 \u0627\u0644\u0627\u0639\u062A\u0645\u0627\u062F \u0639\u0644\u064A\u0647 \u0645\u0646\u0641\u0631\u062F\u0627\u064B \u0644\u0627\u062A\u062E\u0627\u0630 \u0642\u0631\u0627\u0631\u0627\u062A \u0634\u0631\u0627\u0621 \u0623\u0648 \u0628\u064A\u0639 \u0623\u0648 \u062A\u062D\u0648\u064A\u0644 \u0623\u0645\u0648\u0627\u0644."),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u064A\u064F\u0646\u0635\u064E\u062D \u062F\u0627\u0626\u0645\u0627\u064B \u0628\u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u062C\u0647\u0627\u062A \u0627\u0644\u0631\u0633\u0645\u064A\u0629 (\u0645\u0635\u0631\u0641 \u0633\u0648\u0631\u064A\u0629 \u0627\u0644\u0645\u0631\u0643\u0632\u064A\u060C \u0627\u0644\u0645\u0635\u0627\u0631\u0641 \u0627\u0644\u0645\u0631\u062E\u0651\u064E\u0635\u0629\u060C \u0634\u0631\u0643\u0627\u062A \u0627\u0644\u0635\u0631\u0627\u0641\u0629 \u0627\u0644\u0646\u0638\u0627\u0645\u064A\u0629) \u0642\u0628\u0644 \u0627\u0644\u0642\u064A\u0627\u0645 \u0628\u0623\u064A \u0645\u0639\u0627\u0645\u0644\u0629 \u0645\u0627\u0644\u064A\u0629 \u0623\u0648 \u062A\u062C\u0627\u0631\u064A\u0629 \u062A\u0639\u062A\u0645\u062F \u0639\u0644\u0649 \u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0635\u0631\u0641."),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0643 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639\u060C \u0641\u0625\u0646\u0643 \u062A\u0642\u0631\u0651 \u0628\u0623\u0646\u0643 \u062A\u062A\u062D\u0645\u0651\u0644 \u0648\u062D\u062F\u0643 \u0643\u0627\u0645\u0644 \u0627\u0644\u0645\u0633\u0624\u0648\u0644\u064A\u0629 \u0639\u0646 \u0623\u064A \u0642\u0631\u0627\u0631 \u0645\u0627\u0644\u064A \u0623\u0648 \u062A\u062C\u0627\u0631\u064A \u062A\u062A\u062E\u0630\u0647 \u0628\u0646\u0627\u0621\u064B \u0639\u0644\u0649 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629\u060C \u0648\u0623\u0646\u0643 \u062A\u064F\u062E\u0644\u064A \u0645\u0633\u0624\u0648\u0644\u064A\u0629 \u0645\u0627\u0644\u0643 \u0648\u0645\u0637\u0648\u0651\u0631 \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0645\u0646 \u0623\u064A \u0623\u0636\u0631\u0627\u0631 \u0623\u0648 \u062E\u0633\u0627\u0626\u0631 \u0645\u0628\u0627\u0634\u0631\u0629 \u0623\u0648 \u063A\u064A\u0631 \u0645\u0628\u0627\u0634\u0631\u0629 \u0646\u0627\u062A\u062C\u0629 \u0639\u0646 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0647 \u0623\u0648 \u0639\u0646 \u0623\u064A \u062E\u0637\u0623 \u0623\u0648 \u0627\u0646\u0642\u0637\u0627\u0639 \u0641\u064A \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A."),
                    React.createElement("button", { onClick: () => setShowLegal(false), className: "mt-2 text-xs font-bold text-indigo-600 hover:text-indigo-800" }, t.closeLegal)))),
        React.createElement("div", { className: "space-y-4 pt-4 border-t border-black/5 pb-10 px-4 mt-6" },
            React.createElement("h3", { className: "text-base font-black text-slate-600 px-2 uppercase tracking-widest" }, t.faqTitle),
            FAQ_DATA.slice(0, 2).map((item, index) => (React.createElement(FaqCard, { key: index, item: item, t: t }))),
            React.createElement("div", { className: `slider-content ${showAllFaq ? 'open' : ''}` },
                React.createElement("div", { className: "space-y-4 pt-1" }, FAQ_DATA.slice(2).map((item, index) => (React.createElement(FaqCard, { key: index + 2, item: item, t: t }))))),
            React.createElement("button", { onClick: () => setShowAllFaq(!showAllFaq), className: "w-full py-3.5 rounded-2xl bg-white border border-slate-200 text-slate-700 font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-50 transition-colors" },
                React.createElement("span", null, showAllFaq ? t.lessFaq : t.moreFaq),
                React.createElement("span", { className: `transform transition-transform duration-300 ${showAllFaq ? 'rotate-180' : ''}` },
                    React.createElement(IconChevronDown, null)))),
        React.createElement(Footer, { t: t })));
};
const UnifiedCalculator = ({ t, lang }) => {
    const isAr = lang === 'ar';
    const [vals, setVals] = useState({ reqOld: '', reqNew: '', recOld: '', recNew: '' });
    const [showExample, setShowExample] = useState(false);
    const parseNumbers = (str) => { const map = { '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9' }; return str.replace(/[٠-٩]/g, (d) => map[d]).replace(/[^0-9.]/g, ''); };
    const handleChange = (e) => { const { name, value } = e.target; setVals(prev => ({ ...prev, [name]: parseNumbers(value) })); };
    const handleClear = () => setVals({ reqOld: '', reqNew: '', recOld: '', recNew: '' });
    const applyExample = () => { setVals({ reqOld: '', reqNew: '1750', recOld: '100000', recNew: '1000' }); setShowExample(false); };
    const reqTotalNew = (parseFloat(vals.reqNew) || 0) + ((parseFloat(vals.reqOld) || 0) / RATE);
    const recTotalNew = (parseFloat(vals.recNew) || 0) + ((parseFloat(vals.recOld) || 0) / RATE);
    const diffNew = recTotalNew - reqTotalNew;
    const epsilon = 0.01;
    let status = 'neutral';
    if (reqTotalNew > 0 || recTotalNew > 0) {
        if (Math.abs(diffNew) < epsilon)
            status = 'good';
        else if (diffNew < 0)
            status = 'bad';
        else
            status = 'over';
    }
    const scenariosNew = useMemo(() => { if (status !== 'over')
        return []; return getScenarios(diffNew, DENOMS_NEW_CHANGE, 4); }, [diffNew, status]);
    const scenariosOld = useMemo(() => { if (status !== 'over')
        return []; return getScenarios(diffNew * RATE, DENOMS_OLD_CHANGE, 4); }, [diffNew, status]);
    const shortageScenariosNew = useMemo(() => { if (status !== 'bad')
        return []; return getScenarios(Math.abs(diffNew), DENOMS_NEW_CHANGE, 4); }, [diffNew, status]);
    const shortageScenariosOld = useMemo(() => { if (status !== 'bad')
        return []; return getScenarios(Math.abs(diffNew) * RATE, DENOMS_OLD_CHANGE, 4); }, [diffNew, status]);
    return (React.createElement("div", { className: "app-container-wrapper pb-20" },
        React.createElement("div", { className: "flex justify-between items-center pt-2 px-4 mb-4 mt-4" },
            React.createElement("div", { className: "flex items-center gap-2" },
                React.createElement("h1", { className: "text-2xl font-black text-slate-800" }, t.tab2)),
            React.createElement("div", { className: "flex items-center gap-2" },
                React.createElement("button", { onClick: () => setShowExample(!showExample), className: "flex items-center gap-1.5 bg-blue-50 text-blue-600 px-3 py-1.5 rounded-xl text-sm font-black hover:bg-blue-100 transition shadow-sm border border-blue-100" },
                    React.createElement(IconBulbSmall, null),
                    " ",
                    React.createElement("span", null, t.showExample)),
                React.createElement("button", { onClick: handleClear, type: "button", "aria-label": (isAr ? "مسح" : "Clear"), className: "p-2 bg-white rounded-xl shadow-sm text-red-500 border border-slate-100 hover:bg-red-50 transition" },
                    React.createElement(IconTrash, null)))),
        React.createElement("div", { className: `slider-content ${showExample ? 'open' : ''}` },
            React.createElement("div", { className: "mx-4 mb-4 bg-blue-50 border border-blue-100 rounded-2xl p-5 shadow-sm" },
                React.createElement("h4", { className: "font-black text-blue-800 text-lg mb-2" }, t.exampleTitle),
                React.createElement("p", { className: "text-base font-bold text-blue-700 leading-relaxed mb-4 whitespace-pre-line" }, t.exampleText),
                React.createElement("button", { onClick: applyExample, className: "w-full py-3 bg-blue-600 text-white rounded-xl text-sm font-black shadow-md hover:bg-blue-700 transition" }, t.applyExample))),
        React.createElement("div", { className: "grid gap-4 px-4" },
            React.createElement("div", { className: "app-card p-5 shadow-sm border border-slate-200" },
                React.createElement("div", { className: "flex items-center gap-2 justify-center mb-3" },
                    React.createElement("span", { className: "text-2xl" }, "\uD83E\uDDFE"),
                    React.createElement("p", { className: "text-center text-sm font-black text-slate-700 uppercase tracking-widest" }, t.billTitle)),
                React.createElement("div", { className: "grid grid-cols-2 gap-3" },
                    React.createElement("input", { type: "text", dir: "ltr", inputMode: "decimal", name: "reqNew", value: vals.reqNew, onChange: handleChange, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.billNewPh, className: "w-full h-16 bg-slate-50 rounded-2xl text-center text-2xl font-black outline-none border-none focus:ring-2 focus:ring-blue-500/20" }),
                    React.createElement("input", { type: "text", dir: "ltr", inputMode: "decimal", name: "reqOld", value: vals.reqOld, onChange: handleChange, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.billOldPh, className: "w-full h-16 bg-slate-50 rounded-2xl text-center text-2xl font-black outline-none border-none focus:ring-2 focus:ring-blue-500/20" }))),
            React.createElement("div", { className: "app-card p-5 shadow-sm border-2 border-blue-500" },
                React.createElement("div", { className: "flex items-center gap-2 justify-center mb-3" },
                    React.createElement("span", { className: "text-2xl" }, "\uD83D\uDCB0"),
                    React.createElement("p", { className: "text-center text-sm font-black text-blue-800 uppercase tracking-widest" }, t.paidTitle)),
                React.createElement("div", { className: "grid grid-cols-2 gap-3" },
                    React.createElement("input", { type: "text", dir: "ltr", inputMode: "decimal", name: "recNew", value: vals.recNew, onChange: handleChange, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.paidNewPh, className: "w-full h-16 bg-blue-50/30 rounded-2xl text-center text-2xl font-black outline-none border-none focus:ring-2 focus:ring-blue-500/20" }),
                    React.createElement("input", { type: "text", dir: "ltr", inputMode: "decimal", name: "recOld", value: vals.recOld, onChange: handleChange, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.paidOldPh, className: "w-full h-16 bg-blue-50/30 rounded-2xl text-center text-2xl font-black outline-none border-none focus:ring-2 focus:ring-blue-500/20" })))),
        React.createElement("div", { className: `mx-4 mt-4 rounded-[2.5rem] p-8 text-center shadow-xl relative overflow-hidden transition-all duration-300 ${status === 'good' ? 'bg-[#064e3b]' : status === 'bad' ? 'bg-[#7f1d1d]' : status === 'over' ? 'bg-[#1e3a8a]' : 'bg-slate-800'}` },
            React.createElement("div", { className: `absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${status === 'good' ? 'from-emerald-400 to-green-300' : status === 'bad' ? 'from-red-400 to-orange-300' : 'from-blue-400 to-cyan-300'}` }),
            React.createElement("div", { className: "flex flex-col items-center justify-center min-h-[140px]" }, status === 'neutral' ? (React.createElement("p", { className: "text-white/40 font-bold whitespace-pre-line leading-relaxed text-lg" }, t.enterToShow)) : (React.createElement(React.Fragment, null,
                React.createElement("div", { className: "mb-4" },
                    status === 'good' && React.createElement(IconCheck, null),
                    status === 'bad' && React.createElement(IconWarn, null),
                    status === 'over' && React.createElement(IconInfo, null)),
                React.createElement("h2", { className: "text-3xl font-black text-white mb-6" }, status === 'good' ? t.checkStatusGood : status === 'bad' ? t.checkStatusBad : t.checkStatusOver),
                React.createElement("div", { className: "w-full border-t border-white/10 pt-4 mb-4" },
                    React.createElement("p", { className: "text-white/60 text-xs font-bold uppercase tracking-widest mb-1" }, t.checkTotalRec),
                    React.createElement("div", { className: "flex justify-center gap-4 text-white" },
                        React.createElement("span", { className: "font-mono font-bold text-lg" },
                            recTotalNew.toLocaleString(),
                            " ",
                            t.new),
                        React.createElement("span", { className: "text-white/40" }, "\u2248"),
                        React.createElement("span", { className: "font-mono font-bold text-lg" },
                            (recTotalNew * RATE).toLocaleString(),
                            " ",
                            t.old))),
                status !== 'good' && (React.createElement("div", { className: "w-full bg-black/20 rounded-xl p-3" },
                    React.createElement("p", { className: "text-white/60 text-xs font-bold uppercase tracking-widest mb-1" }, status === 'over' ? t.checkDiff : t.checkDiffShort),
                    React.createElement("div", { className: "text-4xl font-black text-white font-mono dir-ltr" },
                        Math.abs(diffNew).toLocaleString(),
                        " ",
                        t.new),
                    React.createElement("div", { className: "text-lg font-bold text-white/70 font-mono mt-1" },
                        (Math.abs(diffNew) * RATE).toLocaleString(),
                        " ",
                        t.old))))))),
        (status === 'over' || status === 'bad') && (React.createElement("div", { className: "space-y-6 animate-fade-in border-t border-slate-100 pt-6 px-4" },
            React.createElement("h3", { className: `text-center text-base font-black uppercase tracking-widest mb-4 ${status === 'over' ? 'text-blue-800' : 'text-indigo-800'}` },
                "\u2B07\uFE0F ",
                status === 'over' ? t.scenarioNew : t.shortageNew,
                " \u2B07\uFE0F"),
            React.createElement("div", { className: "space-y-3" },
                React.createElement("div", { className: "flex flex-wrap gap-2 items-stretch justify-center" }, (status === 'over' ? scenariosNew : shortageScenariosNew).map((items, idx) => (React.createElement("div", { key: `new-${idx}`, className: `flex-auto min-w-[140px] rounded-2xl border bg-white p-4 shadow-sm flex flex-col justify-center ${status === 'over' ? 'border-blue-100' : 'border-indigo-100'}` },
                    React.createElement("div", { className: "mb-2 flex items-center gap-2 justify-center" },
                        React.createElement("span", { className: `px-3 py-1 rounded text-xs font-black uppercase tracking-widest ${status === 'over' ? 'bg-blue-50 text-blue-700' : 'bg-indigo-50 text-indigo-700'}` },
                            t.opt,
                            " ",
                            idx + 1)),
                    React.createElement("div", { className: "flex flex-wrap gap-2 justify-center" }, items.map((item, i) => (React.createElement("div", { key: i, className: `inline-flex flex-col items-center justify-center rounded-xl py-2 px-3 border min-w-[80px] ${status === 'over' ? 'bg-emerald-50/20 border-emerald-100/50' : 'bg-slate-50/50 border-slate-200'}` },
                        React.createElement("span", { className: "text-2xl font-black text-slate-900 tabular-nums leading-none" }, item.val),
                        React.createElement("span", { className: `text-xs font-bold mt-1 ${status === 'over' ? 'text-emerald-700' : 'text-slate-500'}` },
                            "x",
                            item.count)))))))))),
            React.createElement("div", { className: "space-y-3 pt-4" },
                React.createElement("div", { className: `text-center text-sm font-bold mb-2 ${status === 'over' ? 'text-emerald-700' : 'text-slate-500'}` }, status === 'over' ? t.scenarioOld : t.shortageOld),
                React.createElement("div", { className: "flex flex-wrap gap-2 items-stretch justify-center" }, (status === 'over' ? scenariosOld : shortageScenariosOld).map((items, idx) => (React.createElement("div", { key: `old-${idx}`, className: `flex-auto min-w-[140px] rounded-2xl border bg-white p-4 shadow-sm flex flex-col justify-center ${status === 'over' ? 'border-emerald-100' : 'border-slate-100'}` },
                    React.createElement("div", { className: "mb-2 flex items-center gap-2 justify-center" },
                        React.createElement("span", { className: `px-3 py-1 rounded text-xs font-black uppercase tracking-widest ${status === 'over' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-50 text-slate-500'}` },
                            t.opt,
                            " ",
                            idx + 1)),
                    React.createElement("div", { className: "flex flex-wrap gap-2 justify-center" }, items.map((item, i) => (React.createElement("div", { key: i, className: `inline-flex flex-col items-center justify-center rounded-xl py-2 px-3 border min-w-[80px] ${status === 'over' ? 'bg-emerald-50/20 border-emerald-100/50' : 'bg-slate-50/50 border-slate-200'}` },
                        React.createElement("span", { className: "text-2xl font-black text-slate-900 tabular-nums leading-none" }, item.val),
                        React.createElement("span", { className: `text-xs font-bold mt-1 ${status === 'over' ? 'text-emerald-700' : 'text-slate-500'}` },
                            "x",
                            item.count)))))))))))),
        React.createElement(Footer, { t: t })));
};
function ElectricityCalculator({ lang }) {
    const [consumption, setConsumption] = useState('');
    const [subscriberType, setSubscriberType] = useState('residential');
    const [isExempt, setIsExempt] = useState(false);

    // Inject required styles (scoped by class names)
    useEffect(() => {
        if (document.getElementById('mylira-electric-css')) return;
        const style = document.createElement('style');
        style.id = 'mylira-electric-css';
        style.textContent = `
            .result-card { background: linear-gradient(135deg, #059669 0%, #10b981 100%); }
            .animate-pop { animation: pop 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
            @keyframes pop { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        `;
        document.head.appendChild(style);
    }, []);

    const convertArabicNumbers = (str) => {
        const dict = { '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9' };
        return (str || '').replace(/[٠-٩]/g, (d) => dict[d]);
    };

    const handleInputChange = (e) => {
        const val = convertArabicNumbers(e.target.value);
        if (/^\d*\.?\d*$/.test(val)) setConsumption(val);
    };

    // Hide keyboard when swiping down
    useEffect(() => {
        let startY = 0;
        const handleTouchStart = (e) => { startY = e.touches[0].clientY; };
        const handleTouchMove = (e) => {
            const currentY = e.touches[0].clientY;
            if (currentY - startY > 40) {
                try { document.activeElement && document.activeElement.blur && document.activeElement.blur(); } catch (err) {}
            }
        };
        window.addEventListener('touchstart', handleTouchStart, { passive: true });
        window.addEventListener('touchmove', handleTouchMove, { passive: true });
        return () => {
            window.removeEventListener('touchstart', handleTouchStart);
            window.removeEventListener('touchmove', handleTouchMove);
        };
    }, []);

    const quickValues = [100, 200, 300, 400, 500, 1000];

    const subscriberOptions = useMemo(() => ([
        { id: 'residential', label: lang === 'en' ? 'Residential' : 'سكني' },
        { id: 'public', label: lang === 'en' ? 'Public sector' : 'قطاع عام' },
        { id: 'private', label: lang === 'en' ? 'Private sector' : 'قطاع خاص' },
        { id: 'industrial_high', label: lang === 'en' ? 'Industrial (high)' : 'صناعي (استهلاك عالي)' },
        { id: 'agricultural', label: lang === 'en' ? 'Agricultural' : 'زراعي' },
        { id: 'commercial', label: lang === 'en' ? 'Commercial' : 'تجاري' },
        { id: 'tourist', label: lang === 'en' ? 'Tourism' : 'سياحي' },
        { id: 'charity', label: lang === 'en' ? 'Charity' : 'خيري' },
        { id: 'temporary', label: lang === 'en' ? 'Temporary use' : 'استخدام مؤقت' },
        { id: 'advertising', label: lang === 'en' ? 'Advertising administration' : 'إدارة إعلانية' },
    ]), [lang]);

    const calculation = useMemo(() => {
        const val = parseFloat(consumption) || 0;
        let totalOld = 0;
        const slabs = [];

        if (subscriberType === 'residential') {
            if (val <= 300) {
                totalOld = val * 600;
                slabs.push({ range: lang === 'en' ? 'Slab 1 (1-300)' : 'الشريحة الأولى (1-300)', price: 600, cost: totalOld });
            } else {
                const s1 = 300 * 600;
                const s2 = (val - 300) * 1400;
                totalOld = s1 + s2;
                slabs.push({ range: lang === 'en' ? 'Slab 1 (1-300)' : 'الشريحة الأولى (1-300)', price: 600, cost: s1 });
                slabs.push({ range: lang === 'en' ? 'Slab 2 (>300)' : 'الشريحة الثانية (>300)', price: 1400, cost: s2 });
            }
        } else if (subscriberType === 'advertising') {
            const price = isExempt ? 1700 : 1800;
            totalOld = val * price;
            slabs.push({ range: (lang === 'en'
                ? `Advertising (${isExempt ? 'Exempt' : 'Subject'})`
                : `إدارة إعلانية (${isExempt ? 'معفى' : 'خاضع'})`), price, cost: totalOld });
        } else {
            const price = isExempt ? 1700 : 1400;
            totalOld = val * price;
            slabs.push({ range: (lang === 'en'
                ? `Flat tariff (${isExempt ? 'Exempt' : 'Subject'})`
                : `تعرفة ثابتة (${isExempt ? 'معفى' : 'خاضع'})`), price, cost: totalOld });
        }

        return { totalOld, totalNew: totalOld / 100, slabs };
    }, [consumption, subscriberType, isExempt, lang]);

    const share = () => {
        const label = (subscriberOptions.find(o => o.id === subscriberType) || {}).label || subscriberType;
        const text = (lang === 'en')
            ? `📊 Estimated electricity bill:\nCategory: ${label}\nConsumption: ${consumption} kWh\nAmount (old): ${calculation.totalOld.toLocaleString()} SYP\nAmount (new): ${calculation.totalNew.toLocaleString()} (new lira)`
            : `📊 فاتورة الكهرباء التقديرية:\nالفئة: ${label}\nالاستهلاك: ${consumption} kWh\nالمبلغ (قديم): ${calculation.totalOld.toLocaleString()} ل.س\nالمبلغ (جديد): ${calculation.totalNew.toLocaleString()} ليرة`;
        window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
    };

    const blurActive = () => { try { document.activeElement && document.activeElement.blur && document.activeElement.blur(); } catch (err) {} };

    return React.createElement("div", {
        className: "app-container-wrapper p-4 pb-20",
        onClick: blurActive
    },
        // Header
        React.createElement("div", { className: "bg-slate-900 text-white p-7 rounded-[2.5rem] shadow-2xl text-center mb-6 select-none" },
            React.createElement("div", { className: "inline-block bg-blue-500/20 p-3 rounded-2xl mb-3" },
                React.createElement("svg", { className: "text-blue-400", width: "28", height: "28", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3" },
                    React.createElement("path", { d: "M13 2L3 14h9l-1 8 10-12h-9l1-8z" })
                )
            ),
            React.createElement("h1", { className: "text-2xl font-black block" }, lang === 'en' ? "Syrian Electricity Calculator" : "حاسبة الكهرباء السورية"),
            React.createElement("p", { className: "text-slate-400 text-sm font-bold mt-2" }, lang === 'en' ? "Based on old & new Syrian lira" : "بناءً على الليرة السورية الجديدة والقديمة")
        ),

        // Inputs card
        React.createElement("div", {
            className: "bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-200 mb-6",
            onClick: (e) => e.stopPropagation()
        },
            React.createElement("label", { className: "text-slate-500 font-black text-xs block mb-3 mr-2" }, lang === 'en' ? "Consumption (kWh)" : "كمية الاستهلاك (kWh)"),
            React.createElement("input", {
                type: "text",
                inputMode: "decimal",
                value: consumption,
                onChange: handleInputChange,
                onKeyDown: (e) => e.key === 'Enter' && e.target.blur(),
                className: "w-full text-5xl font-black p-4 bg-slate-50 rounded-3xl border-none text-center outline-none focus:ring-4 focus:ring-blue-500/10 transition-all mb-4",
                placeholder: lang === 'en' ? "0" : "٠"
            }),

            React.createElement("div", { className: "grid grid-cols-3 gap-2 mb-6" },
                ...quickValues.map(v => React.createElement("button", {
                    key: v,
                    onClick: () => { setConsumption(v.toString()); blurActive(); },
                    className: "py-2.5 bg-slate-100 active:bg-slate-800 active:text-white rounded-xl text-sm font-black transition-all"
                }, v))
            ),

            React.createElement("div", { className: "space-y-4" },
                React.createElement("div", null,
                    React.createElement("label", { className: "text-slate-500 font-black text-xs block mb-2 mr-2" }, lang === 'en' ? "Subscriber category" : "فئة الاشتراك"),
                    React.createElement("select", {
                        value: subscriberType,
                        onChange: (e) => setSubscriberType(e.target.value),
                        className: "w-full p-4 bg-slate-100 rounded-2xl border-none font-bold text-lg outline-none appearance-none cursor-pointer"
                    },
                        ...subscriberOptions.map(opt => React.createElement("option", { key: opt.id, value: opt.id }, opt.label))
                    )
                ),

                subscriberType !== 'residential' && React.createElement("div", { className: "animate-pop" },
                    React.createElement("label", { className: "text-slate-500 font-black text-xs block mb-2 mr-2" }, lang === 'en' ? "Electricity system" : "نظام الكهرباء"),
                    React.createElement("div", { className: "flex gap-2 p-1.5 bg-slate-100 rounded-2xl" },
                        React.createElement("button", {
                            onClick: () => setIsExempt(false),
                            className: `flex-1 py-3 rounded-xl font-black text-sm transition-all ${!isExempt ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`
                        }, lang === 'en' ? "Subject to rationing" : "خاضع للتقنين"),
                        React.createElement("button", {
                            onClick: () => setIsExempt(true),
                            className: `flex-1 py-3 rounded-xl font-black text-sm transition-all ${isExempt ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`
                        }, lang === 'en' ? "Exempt (24h)" : "معفى (٢٤ ساعة)")
                    )
                )
            )
        ),

        // Results
        (parseFloat(consumption) > 0) && React.createElement("div", { className: "animate-pop space-y-4 pb-10" },
            React.createElement("div", { className: "result-card text-white p-8 rounded-[3rem] shadow-xl text-center relative" },
                React.createElement("p", { className: "text-emerald-100 text-xs font-black mb-1 opacity-80" }, lang === 'en' ? "Estimated total bill" : "إجمالي الفاتورة التقديرية"),
                React.createElement("div", { className: "text-5xl font-black mb-3" },
                    calculation.totalOld.toLocaleString(), " ",
                    React.createElement("span", { className: "text-lg" }, lang === 'en' ? "SYP" : "ل.س")
                ),
                React.createElement("div", { className: "w-1/2 h-px bg-white/20 mx-auto my-4" }),
                React.createElement("div", { className: "text-2xl font-bold opacity-90" },
                    calculation.totalNew.toLocaleString(), " ",
                    (lang === 'en' ? "new lira" : "ليرة جديدة")
                )
            ),

            React.createElement("div", { className: "bg-white p-6 rounded-[2.5rem] border border-slate-200" },
                React.createElement("h3", { className: "text-slate-400 font-black text-[10px] mb-4 uppercase tracking-widest mr-2" }, lang === 'en' ? "Pricing details" : "تفاصيل التسعير"),
                React.createElement("div", { className: "space-y-3" },
                    ...calculation.slabs.map((s, i) => React.createElement("div", {
                        key: i,
                        className: "flex justify-between items-center p-4 bg-slate-50 rounded-2xl border border-slate-100"
                    },
                        React.createElement("div", null,
                            React.createElement("div", { className: "font-black text-slate-800 text-xs" }, s.range),
                            React.createElement("div", { className: "text-[10px] font-bold text-blue-500 mt-1" },
                                (lang === 'en' ? "kWh price: " : "سعر الكيلو: "),
                                s.price, " ",
                                (lang === 'en' ? "SYP" : "ل.س")
                            )
                        ),
                        React.createElement("div", { className: "font-black text-slate-900" },
                            s.cost.toLocaleString(), " ",
                            React.createElement("span", { className: "text-[10px]" }, lang === 'en' ? "SYP" : "ل.س")
                        )
                    ))
                )
            ),

            React.createElement("button", {
                onClick: share,
                className: "w-full py-5 bg-blue-600 text-white rounded-[2rem] font-black text-lg shadow-lg hover:bg-blue-700 active:scale-95 transition-all flex items-center justify-center gap-3"
            },
                React.createElement("span", null, lang === 'en' ? "Share on WhatsApp" : "مشاركة عبر واتساب"),
                React.createElement("svg", { width: "22", height: "22", viewBox: "0 0 24 24", fill: "currentColor" },
                    React.createElement("path", { d: "M12.031 6.172c-2.202 0-3.991 1.789-3.991 3.991 0 .585.131 1.153.384 1.671l-.514 1.878 1.921-.504c.5.244 1.054.373 1.621.373 2.201 0 3.991-1.789 3.991-3.991s-1.789-3.991-3.991-3.991zm2.393 5.408c-.103.284-.594.543-.819.58-.225.036-.505.061-1.157-.205-.815-.333-1.342-1.154-1.383-1.209-.041-.055-.326-.434-.326-.827 0-.393.205-.586.279-.668.073-.082.161-.103.214-.103s.103 0 .147.001c.046.001.109-.017.171.131.062.148.212.518.231.555.019.037.031.08.006.13-.025.051-.037.082-.074.126-.037.043-.078.097-.111.131-.038.037-.078.077-.034.153.044.076.196.323.421.523.29.259.534.339.609.376.075.037.12.031.164-.02.044-.051.191-.221.242-.297.051-.076.103-.064.171-.037.069.027.436.206.511.244.075.038.125.056.143.087.018.031.018.179-.085.463z" })
                )
            )
        )
    );
}

function App() {
    const [activeTab, setActiveTab] = useState('converter');
    const [lang, setLang] = useState('ar');

    // Electricity tab gentle attention (auto-hides after a few tab visits)
    const ELEC_NUDGE_MAX_OPENS = 4;
    const [elecOpenCount, setElecOpenCount] = useState(() => {
        try {
            const v = parseInt(localStorage.getItem('mylira_elec_tab_open_count_v1') || '0', 10);
            return Number.isFinite(v) ? v : 0;
        } catch (e) {
            return 0;
        }
    });
    const showElectricityNudge = elecOpenCount < ELEC_NUDGE_MAX_OPENS;
    const prevTabRef = useRef('converter');
    useEffect(() => {
        if (activeTab === 'electricity' && prevTabRef.current !== 'electricity') {
            setElecOpenCount((prev) => {
                const safePrev = Number.isFinite(prev) ? prev : 0;
                const next = safePrev + 1;
                try { localStorage.setItem('mylira_elec_tab_open_count_v1', String(next)); } catch (e) { }
                return next;
            });
        }
        prevTabRef.current = activeTab;
    }, [activeTab]);
    const [rates, setRates] = useState({});
    const [hintStep, setHintStep] = useState(0);
    useEffect(() => {
        const cachedRates = localStorage.getItem('mylira_rates_data');
        if (cachedRates) {
            try {
                setRates(JSON.parse(cachedRates));
            }
            catch (e) { }
        }
        fetch("https://raw.githubusercontent.com/laithi/lira-telegram-bot/main/rates.json").then(res => res.json()).then(data => { if (data.rates) {
            setRates(data.rates);
            localStorage.setItem('mylira_rates_data', JSON.stringify(data.rates));
        } }).catch(() => { });
        const hasSeenHints = localStorage.getItem('mylira_hints_seen_v28');
        if (!hasSeenHints)
            setTimeout(() => setHintStep(1), 1000);
    }, []);
    useEffect(() => {
        let startY = 0;
        const handleTouchStart = (e) => { startY = e.touches[0].clientY; };
        const handleTouchMove = (e) => { const currentY = e.touches[0].clientY; const diff = currentY - startY; if (diff > 30 && document.activeElement && document.activeElement.tagName === 'INPUT') {
            document.activeElement.blur();
        } };
        window.addEventListener('touchstart', handleTouchStart, { passive: true });
        window.addEventListener('touchmove', handleTouchMove, { passive: true });
        return () => { window.removeEventListener('touchstart', handleTouchStart); window.removeEventListener('touchmove', handleTouchMove); };
    }, []);
    const handleNextHint = () => { if (hintStep === 2) {
        setHintStep(0);
        localStorage.setItem('mylira_hints_seen_v28', 'true');
    }
    else {
        setHintStep(prev => prev + 1);
    } };
    const handleSkipHints = () => { setHintStep(0); localStorage.setItem('mylira_hints_seen_v28', 'true'); };
    const t = TEXTS[lang];
    const isAr = lang === 'ar';
    return (React.createElement("div", { className: `min-h-screen pb-10 ${isAr ? 'rtl text-right' : 'ltr text-left'}` },
        React.createElement(SmartHints, { step: hintStep, onNext: handleNextHint, onSkip: handleSkipHints, t: t, isAr: isAr }),
        React.createElement("div", { className: "relative h-[80px] w-full flex items-center justify-between px-4 bg-[#f8fafc] border-b border-black/5 z-20" },
            React.createElement("div", { className: "font-black text-4xl text-indigo-600 tracking-tight relative z-30" }, t.title),
            React.createElement("div", { className: "absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20" },
                React.createElement("img", { src: "https://mylira.online/Log.png", alt: "MyLira", width: "80", height: "80", decoding: "async", fetchpriority: "high", className: "h-20 w-auto object-contain drop-shadow-md animate-fade-in" })),
            React.createElement("button", { onClick: () => setLang(lang === 'ar' ? 'en' : 'ar'), className: "bg-black/5 px-4 py-1.5 rounded-full text-xs font-black text-slate-800/80 relative z-30" }, lang === 'ar' ? 'English' : 'العربية')),
        React.createElement("div", { id: "tabs-container", className: "sticky-tabs flex px-4 border-b border-black/5 relative z-20 bg-[#f8fafc]" },
            React.createElement("button", { onClick: () => setActiveTab('converter'), className: `flex-1 py-4 text-lg font-black transition-all ${activeTab === 'converter' ? 'tab-active' : 'tab-inactive'}` }, t.tab1),
            React.createElement("button", { id: "tab-btn-change", onClick: () => setActiveTab('change'), className: `flex-1 py-4 text-lg font-black transition-all ${activeTab === 'change' ? 'tab-active text-blue-600 border-blue-600' : 'tab-inactive'} ${activeTab !== 'change' ? 'tab-animate-attention' : ''}` }, t.tab2),
                        React.createElement("button", { id: "tab-btn-electricity", onClick: () => setActiveTab('electricity'), className: `flex-1 py-4 text-lg font-black transition-all ${activeTab === 'electricity' ? 'tab-active' : 'tab-inactive'}` },
                React.createElement("span", { className: "inline-flex items-center gap-2" },
                    React.createElement("span", null, t.tab3),
                    (showElectricityNudge && activeTab !== 'electricity') && React.createElement("span", { className: "relative flex h-2 w-2" },
                        React.createElement("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-40" }),
                        React.createElement("span", { className: "relative inline-flex rounded-full h-2 w-2 bg-emerald-500" })
                    )
                )
            )),
        React.createElement("div", { className: "mt-2 relative z-0 pb-32" },
            activeTab === 'converter' && React.createElement(SmartConverter, { lang: lang, t: t, rates: rates }),
            activeTab === 'change' && React.createElement(UnifiedCalculator, { lang: lang, t: t }),
            activeTab === 'electricity' && React.createElement(ElectricityCalculator, { lang: lang, t: t })),
        React.createElement(ScrollToTop, { isAr: isAr }),
        React.createElement(InstallBanner, { t: t, isAr: isAr })));
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(App, null));