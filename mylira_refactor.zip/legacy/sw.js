/* MyLira - simple production SW (cache-first for app shell) */
const CACHE_VERSION = 'mylira-prod-v2';
const APP_SHELL = [
  './',
  './index.html',
  './app.js',
  './manifest.json',
  './Log.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.map((k) => (k === CACHE_VERSION ? null : caches.delete(k))))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;

  // SPA-style navigation fallback
  if (req.mode === 'navigate') {
    event.respondWith(
      caches.match('./index.html').then((cached) => cached || fetch(req))
    );
    return;
  }

  // Only cache GET
  if (req.method !== 'GET') return;

  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;

      return fetch(req)
        .then((res) => {
          // Cache successful (and opaque) responses
          const copy = res.clone();
          caches.open(CACHE_VERSION).then((cache) => {
            // Avoid caching analytics/ads endpoints aggressively
            const url = new URL(req.url);
            const isNoisy = url.hostname.includes('googletagmanager.com') ||
                            url.hostname.includes('google-analytics.com') ||
                            url.hostname.includes('googlesyndication.com');
            if (!isNoisy) cache.put(req, copy);
          });
          return res;
        })
        .catch(() => cached);
    })
  );
});
