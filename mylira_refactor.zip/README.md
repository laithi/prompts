# MyLira Refactor (Vite + Tailwind + Modular React)

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Notes
- Legacy (original) files are in `/legacy` unchanged.
- Service Worker is in `/public/sw.js` and will be copied to the build output.
- Rates URL can be overridden via `.env` (see `.env.example`).
