/* Auto-extracted from legacy app.js */
const RATE = 100;
const DENOMS_NEW_CONVERTER = [{ v: 500, s: '🌾', n: { ar: 'سنابل', en: 'Wheat' } }, { v: 200, s: '🫒', n: { ar: 'زيتون', en: 'Olive' } }, { v: 100, s: '☁️', n: { ar: 'قطن', en: 'Cotton' } }, { v: 50, s: '🍊', n: { ar: 'حمضيات', en: 'Citrus' } }, { v: 25, s: '🍇', n: { ar: 'توت', en: 'Mulberry' } }, { v: 10, s: '🌼', n: { ar: 'ياسمين', en: 'Jasmine' } }];
const DENOMS_OLD_CONVERTER = [{ v: 5000, s: '💶', n: { ar: 'خمسة آلاف', en: '5000' } }, { v: 2000, s: '💶', n: { ar: 'ألفين', en: '2000' } }, { v: 1000, s: '💵', n: { ar: 'ألف', en: '1000' } }, { v: 500, s: '💵', n: { ar: 'خمسمئة', en: '500' } }];
const DENOMS_NEW_VALS_ONLY = DENOMS_NEW_CONVERTER.map(d => d.v);
const DENOMS_OLD_VALS_ONLY = DENOMS_OLD_CONVERTER.map(d => d.v);
const DENOMS_NEW_CHANGE = [500, 200, 100, 50, 25, 20, 10];
const DENOMS_OLD_CHANGE = [5000, 2000, 1000, 500, 200];

export {
  RATE,
  DENOMS_NEW_CONVERTER,
  DENOMS_OLD_CONVERTER,
  DENOMS_NEW_VALS_ONLY,
  DENOMS_OLD_VALS_ONLY,
  DENOMS_NEW_CHANGE,
  DENOMS_OLD_CHANGE
};
