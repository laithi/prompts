/* Auto-extracted from legacy app.js */
const CURRENCY_DETAILS = {
    USD: { ar: "دولار أمريكي", en: "US Dollar" },
    AED: { ar: "درهم إماراتي", en: "UAE Dirham" },
    SAR: { ar: "ريال سعودي", en: "Saudi Riyal" },
    EUR: { ar: "يورو", en: "Euro" },
    KWD: { ar: "دينار كويتي", en: "Kuwaiti Dinar" },
    SEK: { ar: "كرون سويدي", en: "Swedish Krona" },
    GBP: { ar: "جنيه إسترليني", en: "British Pound" },
    JOD: { ar: "دينار أردني", en: "Jordanian Dinar" }
};

export { CURRENCY_DETAILS };