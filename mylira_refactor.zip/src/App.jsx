import React, { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } from 'react';
import SmartConverter from './components/SmartConverter';
import UnifiedCalculator from './components/UnifiedCalculator';
import ElectricityCalculator from './components/ElectricityCalculator';
import InstallBanner from './components/InstallBanner';
import SmartHints from './components/SmartHints';
import ScrollToTop from './components/ScrollToTop';

import { TEXTS } from './constants/texts';
import { useRates } from './hooks/useRates';
import { useHints } from './hooks/useHints';
import { useElectricityNudge } from './hooks/useElectricityNudge';

function App() {
    const [activeTab, setActiveTab] = useState('converter');
    const [lang, setLang] = useState('ar');

    // Electricity tab gentle attention (auto-hides after a few tab visits) — moved to hook
    const { showElectricityNudge } = useElectricityNudge(activeTab);

    // Rates cache + fetch — moved to hook
    const { rates } = useRates();

    // Hints lifecycle — moved to hook
    const { hintStep, setHintStep } = useHints();

    useEffect(() => {
        let startY = 0;
        const handleTouchStart = (e) => { startY = e.touches[0].clientY; };
        const handleTouchMove = (e) => { const currentY = e.touches[0].clientY; const diff = currentY - startY; if (diff > 30 && document.activeElement && document.activeElement.tagName === 'INPUT') {
            document.activeElement.blur();
        } };
        window.addEventListener('touchstart', handleTouchStart, { passive: true });
        window.addEventListener('touchmove', handleTouchMove, { passive: true });
        return () => { window.removeEventListener('touchstart', handleTouchStart); window.removeEventListener('touchmove', handleTouchMove); };
    }, []);
    const handleNextHint = () => { if (hintStep === 2) {
        setHintStep(0);
        localStorage.setItem('mylira_hints_seen_v28', 'true');
    }
    else {
        setHintStep(prev => prev + 1);
    } };
    const handleSkipHints = () => { setHintStep(0); localStorage.setItem('mylira_hints_seen_v28', 'true'); };
    const t = TEXTS[lang];
    const isAr = lang === 'ar';
    return (React.createElement("div", { className: `min-h-screen pb-10 ${isAr ? 'rtl text-right' : 'ltr text-left'}` },
        React.createElement(SmartHints, { step: hintStep, onNext: handleNextHint, onSkip: handleSkipHints, t: t, isAr: isAr }),
        React.createElement("div", { className: "relative h-[80px] w-full flex items-center justify-between px-4 bg-[#f8fafc] border-b border-black/5 z-20" },
            React.createElement("div", { className: "font-black text-4xl text-indigo-600 tracking-tight relative z-30" }, t.title),
            React.createElement("div", { className: "absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20" },
                React.createElement("img", { src: "https://mylira.online/Log.png", alt: "MyLira", width: "80", height: "80", decoding: "async", fetchpriority: "high", className: "h-20 w-auto object-contain drop-shadow-md animate-fade-in" })),
            React.createElement("button", { onClick: () => setLang(lang === 'ar' ? 'en' : 'ar'), className: "bg-black/5 px-4 py-1.5 rounded-full text-xs font-black text-slate-800/80 relative z-30" }, lang === 'ar' ? 'English' : 'العربية')),
        React.createElement("div", { id: "tabs-container", className: "sticky-tabs flex px-4 border-b border-black/5 relative z-20 bg-[#f8fafc]" },
            React.createElement("button", { onClick: () => setActiveTab('converter'), className: `flex-1 py-4 text-lg font-black transition-all ${activeTab === 'converter' ? 'tab-active' : 'tab-inactive'}` }, t.tab1),
            React.createElement("button", { id: "tab-btn-change", onClick: () => setActiveTab('change'), className: `flex-1 py-4 text-lg font-black transition-all ${activeTab === 'change' ? 'tab-active text-blue-600 border-blue-600' : 'tab-inactive'} ${activeTab !== 'change' ? 'tab-animate-attention' : ''}` }, t.tab2),
                        React.createElement("button", { id: "tab-btn-electricity", onClick: () => setActiveTab('electricity'), className: `flex-1 py-4 text-lg font-black transition-all ${activeTab === 'electricity' ? 'tab-active' : 'tab-inactive'}` },
                React.createElement("span", { className: "inline-flex items-center gap-2" },
                    React.createElement("span", null, t.tab3),
                    (showElectricityNudge && activeTab !== 'electricity') && React.createElement("span", { className: "relative flex h-2 w-2" },
                        React.createElement("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-40" }),
                        React.createElement("span", { className: "relative inline-flex rounded-full h-2 w-2 bg-emerald-500" })
                    )
                )
            )),
        React.createElement("div", { className: "mt-2 relative z-0 pb-32" },
            activeTab === 'converter' && React.createElement(SmartConverter, { lang: lang, t: t, rates: rates }),
            activeTab === 'change' && React.createElement(UnifiedCalculator, { lang: lang, t: t }),
            activeTab === 'electricity' && React.createElement(ElectricityCalculator, { lang: lang, t: t })),
        React.createElement(ScrollToTop, { isAr: isAr }),
        React.createElement(InstallBanner, { t: t, isAr: isAr })));
}

export default App;
