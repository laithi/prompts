import React, { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } from 'react';
import { IconArrowUp } from './shared/Icons';
const ScrollToTop = ({ isAr }) => {
    const [visible, setVisible] = useState(false);
    useEffect(() => {
        const toggleVisibility = () => { if (window.pageYOffset > 300)
            setVisible(true);
        else
            setVisible(false); };
        window.addEventListener('scroll', toggleVisibility);
        return () => window.removeEventListener('scroll', toggleVisibility);
    }, []);
    const scrollToTop = () => { window.scrollTo({ top: 0, behavior: 'smooth' }); };
    if (!visible)
        return null;
    return (React.createElement("button", { onClick: scrollToTop, className: `fixed bottom-24 ${isAr ? 'left-6' : 'right-6'} z-40 bg-indigo-600/90 backdrop-blur text-white w-12 h-12 flex items-center justify-center rounded-full shadow-lg shadow-indigo-600/30 hover:bg-indigo-700 transition-all active:scale-95 animate-scale-up md:right-[calc(50%-350px)] lg:right-[calc(50%-480px)]`, "aria-label": "Back to top" },
        React.createElement(IconArrowUp, null)));
};

export default ScrollToTop;

