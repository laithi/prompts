import React, { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } from 'react';
import { IconClose, IconDotsAndroid, IconPlusBox, IconShareIOS } from './shared/Icons';
const InstallBanner = ({ t, isAr }) => {
    const [show, setShow] = useState(false);
    const [os, setOs] = useState(null);
    useEffect(() => {
        const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
        if (isStandalone)
            return;
        const isClosed = localStorage.getItem('mylira_install_banner_closed_v1');
        if (isClosed)
            return;
        const ua = navigator.userAgent || navigator.vendor || window.opera;
        if (/iPad|iPhone|iPod/.test(ua) && !window.MSStream) {
            setOs('ios');
            setShow(true);
        }
        else if (/android/i.test(ua)) {
            setOs('android');
            setShow(true);
        }
    }, []);
    const handleClose = () => { setShow(false); localStorage.setItem('mylira_install_banner_closed_v1', 'true'); };
    if (!show)
        return null;
    return (React.createElement("div", { className: "fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-[0_-4px_20px_rgba(0,0,0,0.1)] p-4 pb-6 animate-fade-in safe-area-bottom md:max-w-md md:left-1/2 md:-translate-x-1/2 rounded-t-2xl" },
        React.createElement("div", { className: "max-w-md mx-auto relative pr-8" },
            React.createElement("button", { onClick: handleClose, type: "button", "aria-label": (isAr ? "إغلاق" : "Close"), className: "absolute -top-1 -right-2 p-2 text-slate-400 hover:text-red-500" },
                React.createElement(IconClose, null)),
            React.createElement("div", { className: "flex items-center gap-3 mb-2" },
                React.createElement("span", { className: "text-2xl" }, "\uD83D\uDCF2"),
                React.createElement("h3", { className: "font-black text-sm text-slate-800" }, t.installTitle)),
            React.createElement("div", { className: "text-xs font-bold text-slate-600 leading-relaxed flex flex-wrap items-center gap-1" }, os === 'ios' ? (React.createElement(React.Fragment, null,
                React.createElement("span", null, t.installIOS),
                React.createElement("span", { className: "inline-flex items-center justify-center w-6 h-6 bg-slate-100 rounded border border-slate-200 mx-0.5" },
                    React.createElement(IconShareIOS, null)),
                React.createElement("span", null, t.installIOS2),
                React.createElement("span", { className: "inline-flex items-center justify-center w-6 h-6 bg-slate-100 rounded border border-slate-200 mx-0.5" },
                    React.createElement(IconPlusBox, null)))) : (React.createElement(React.Fragment, null,
                React.createElement("span", null, t.installAndroid),
                React.createElement("span", { className: "inline-flex items-center justify-center w-6 h-6 bg-slate-100 rounded border border-slate-200 mx-0.5" },
                    React.createElement(IconDotsAndroid, null)),
                React.createElement("span", null, t.installAndroid2)))))));
};

export default InstallBanner;

