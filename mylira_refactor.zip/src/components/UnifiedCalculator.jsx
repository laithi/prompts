import React, { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } from 'react';
import { IconBulbSmall, IconCheck, IconInfo, IconTrash, IconWarn } from './shared/Icons';
import { RATE, DENOMS_NEW_CHANGE, DENOMS_OLD_CHANGE } from '../constants/denoms';
import { getScenarios, formatRes } from '../utils/calculations';
const UnifiedCalculator = ({ t, lang }) => {
    const isAr = lang === 'ar';
    const [vals, setVals] = useState({ reqOld: '', reqNew: '', recOld: '', recNew: '' });
    const [showExample, setShowExample] = useState(false);
    const parseNumbers = (str) => { const map = { '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9' }; return str.replace(/[٠-٩]/g, (d) => map[d]).replace(/[^0-9.]/g, ''); };
    const handleChange = (e) => { const { name, value } = e.target; setVals(prev => ({ ...prev, [name]: parseNumbers(value) })); };
    const handleClear = () => setVals({ reqOld: '', reqNew: '', recOld: '', recNew: '' });
    const applyExample = () => { setVals({ reqOld: '', reqNew: '1750', recOld: '100000', recNew: '1000' }); setShowExample(false); };
    const reqTotalNew = (parseFloat(vals.reqNew) || 0) + ((parseFloat(vals.reqOld) || 0) / RATE);
    const recTotalNew = (parseFloat(vals.recNew) || 0) + ((parseFloat(vals.recOld) || 0) / RATE);
    const diffNew = recTotalNew - reqTotalNew;
    const epsilon = 0.01;
    let status = 'neutral';
    if (reqTotalNew > 0 || recTotalNew > 0) {
        if (Math.abs(diffNew) < epsilon)
            status = 'good';
        else if (diffNew < 0)
            status = 'bad';
        else
            status = 'over';
    }
    const scenariosNew = useMemo(() => { if (status !== 'over')
        return []; return getScenarios(diffNew, DENOMS_NEW_CHANGE, 4); }, [diffNew, status]);
    const scenariosOld = useMemo(() => { if (status !== 'over')
        return []; return getScenarios(diffNew * RATE, DENOMS_OLD_CHANGE, 4); }, [diffNew, status]);
    const shortageScenariosNew = useMemo(() => { if (status !== 'bad')
        return []; return getScenarios(Math.abs(diffNew), DENOMS_NEW_CHANGE, 4); }, [diffNew, status]);
    const shortageScenariosOld = useMemo(() => { if (status !== 'bad')
        return []; return getScenarios(Math.abs(diffNew) * RATE, DENOMS_OLD_CHANGE, 4); }, [diffNew, status]);
    return (React.createElement("div", { className: "app-container-wrapper pb-20" },
        React.createElement("div", { className: "flex justify-between items-center pt-2 px-4 mb-4 mt-4" },
            React.createElement("div", { className: "flex items-center gap-2" },
                React.createElement("h1", { className: "text-2xl font-black text-slate-800" }, t.tab2)),
            React.createElement("div", { className: "flex items-center gap-2" },
                React.createElement("button", { onClick: () => setShowExample(!showExample), className: "flex items-center gap-1.5 bg-blue-50 text-blue-600 px-3 py-1.5 rounded-xl text-sm font-black hover:bg-blue-100 transition shadow-sm border border-blue-100" },
                    React.createElement(IconBulbSmall, null),
                    " ",
                    React.createElement("span", null, t.showExample)),
                React.createElement("button", { onClick: handleClear, type: "button", "aria-label": (isAr ? "مسح" : "Clear"), className: "p-2 bg-white rounded-xl shadow-sm text-red-500 border border-slate-100 hover:bg-red-50 transition" },
                    React.createElement(IconTrash, null)))),
        React.createElement("div", { className: `slider-content ${showExample ? 'open' : ''}` },
            React.createElement("div", { className: "mx-4 mb-4 bg-blue-50 border border-blue-100 rounded-2xl p-5 shadow-sm" },
                React.createElement("h4", { className: "font-black text-blue-800 text-lg mb-2" }, t.exampleTitle),
                React.createElement("p", { className: "text-base font-bold text-blue-700 leading-relaxed mb-4 whitespace-pre-line" }, t.exampleText),
                React.createElement("button", { onClick: applyExample, className: "w-full py-3 bg-blue-600 text-white rounded-xl text-sm font-black shadow-md hover:bg-blue-700 transition" }, t.applyExample))),
        React.createElement("div", { className: "grid gap-4 px-4" },
            React.createElement("div", { className: "app-card p-5 shadow-sm border border-slate-200" },
                React.createElement("div", { className: "flex items-center gap-2 justify-center mb-3" },
                    React.createElement("span", { className: "text-2xl" }, "\uD83E\uDDFE"),
                    React.createElement("p", { className: "text-center text-sm font-black text-slate-700 uppercase tracking-widest" }, t.billTitle)),
                React.createElement("div", { className: "grid grid-cols-2 gap-3" },
                    React.createElement("input", { type: "text", dir: "ltr", inputMode: "decimal", name: "reqNew", value: vals.reqNew, onChange: handleChange, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.billNewPh, className: "w-full h-16 bg-slate-50 rounded-2xl text-center text-2xl font-black outline-none border-none focus:ring-2 focus:ring-blue-500/20" }),
                    React.createElement("input", { type: "text", dir: "ltr", inputMode: "decimal", name: "reqOld", value: vals.reqOld, onChange: handleChange, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.billOldPh, className: "w-full h-16 bg-slate-50 rounded-2xl text-center text-2xl font-black outline-none border-none focus:ring-2 focus:ring-blue-500/20" }))),
            React.createElement("div", { className: "app-card p-5 shadow-sm border-2 border-blue-500" },
                React.createElement("div", { className: "flex items-center gap-2 justify-center mb-3" },
                    React.createElement("span", { className: "text-2xl" }, "\uD83D\uDCB0"),
                    React.createElement("p", { className: "text-center text-sm font-black text-blue-800 uppercase tracking-widest" }, t.paidTitle)),
                React.createElement("div", { className: "grid grid-cols-2 gap-3" },
                    React.createElement("input", { type: "text", dir: "ltr", inputMode: "decimal", name: "recNew", value: vals.recNew, onChange: handleChange, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.paidNewPh, className: "w-full h-16 bg-blue-50/30 rounded-2xl text-center text-2xl font-black outline-none border-none focus:ring-2 focus:ring-blue-500/20" }),
                    React.createElement("input", { type: "text", dir: "ltr", inputMode: "decimal", name: "recOld", value: vals.recOld, onChange: handleChange, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.paidOldPh, className: "w-full h-16 bg-blue-50/30 rounded-2xl text-center text-2xl font-black outline-none border-none focus:ring-2 focus:ring-blue-500/20" })))),
        React.createElement("div", { className: `mx-4 mt-4 rounded-[2.5rem] p-8 text-center shadow-xl relative overflow-hidden transition-all duration-300 ${status === 'good' ? 'bg-[#064e3b]' : status === 'bad' ? 'bg-[#7f1d1d]' : status === 'over' ? 'bg-[#1e3a8a]' : 'bg-slate-800'}` },
            React.createElement("div", { className: `absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${status === 'good' ? 'from-emerald-400 to-green-300' : status === 'bad' ? 'from-red-400 to-orange-300' : 'from-blue-400 to-cyan-300'}` }),
            React.createElement("div", { className: "flex flex-col items-center justify-center min-h-[140px]" }, status === 'neutral' ? (React.createElement("p", { className: "text-white/40 font-bold whitespace-pre-line leading-relaxed text-lg" }, t.enterToShow)) : (React.createElement(React.Fragment, null,
                React.createElement("div", { className: "mb-4" },
                    status === 'good' && React.createElement(IconCheck, null),
                    status === 'bad' && React.createElement(IconWarn, null),
                    status === 'over' && React.createElement(IconInfo, null)),
                React.createElement("h2", { className: "text-3xl font-black text-white mb-6" }, status === 'good' ? t.checkStatusGood : status === 'bad' ? t.checkStatusBad : t.checkStatusOver),
                React.createElement("div", { className: "w-full border-t border-white/10 pt-4 mb-4" },
                    React.createElement("p", { className: "text-white/60 text-xs font-bold uppercase tracking-widest mb-1" }, t.checkTotalRec),
                    React.createElement("div", { className: "flex justify-center gap-4 text-white" },
                        React.createElement("span", { className: "font-mono font-bold text-lg" },
                            recTotalNew.toLocaleString(),
                            " ",
                            t.new),
                        React.createElement("span", { className: "text-white/40" }, "\u2248"),
                        React.createElement("span", { className: "font-mono font-bold text-lg" },
                            (recTotalNew * RATE).toLocaleString(),
                            " ",
                            t.old))),
                status !== 'good' && (React.createElement("div", { className: "w-full bg-black/20 rounded-xl p-3" },
                    React.createElement("p", { className: "text-white/60 text-xs font-bold uppercase tracking-widest mb-1" }, status === 'over' ? t.checkDiff : t.checkDiffShort),
                    React.createElement("div", { className: "text-4xl font-black text-white font-mono dir-ltr" },
                        Math.abs(diffNew).toLocaleString(),
                        " ",
                        t.new),
                    React.createElement("div", { className: "text-lg font-bold text-white/70 font-mono mt-1" },
                        (Math.abs(diffNew) * RATE).toLocaleString(),
                        " ",
                        t.old))))))),
        (status === 'over' || status === 'bad') && (React.createElement("div", { className: "space-y-6 animate-fade-in border-t border-slate-100 pt-6 px-4" },
            React.createElement("h3", { className: `text-center text-base font-black uppercase tracking-widest mb-4 ${status === 'over' ? 'text-blue-800' : 'text-indigo-800'}` },
                "\u2B07\uFE0F ",
                status === 'over' ? t.scenarioNew : t.shortageNew,
                " \u2B07\uFE0F"),
            React.createElement("div", { className: "space-y-3" },
                React.createElement("div", { className: "flex flex-wrap gap-2 items-stretch justify-center" }, (status === 'over' ? scenariosNew : shortageScenariosNew).map((items, idx) => (React.createElement("div", { key: `new-${idx}`, className: `flex-auto min-w-[140px] rounded-2xl border bg-white p-4 shadow-sm flex flex-col justify-center ${status === 'over' ? 'border-blue-100' : 'border-indigo-100'}` },
                    React.createElement("div", { className: "mb-2 flex items-center gap-2 justify-center" },
                        React.createElement("span", { className: `px-3 py-1 rounded text-xs font-black uppercase tracking-widest ${status === 'over' ? 'bg-blue-50 text-blue-700' : 'bg-indigo-50 text-indigo-700'}` },
                            t.opt,
                            " ",
                            idx + 1)),
                    React.createElement("div", { className: "flex flex-wrap gap-2 justify-center" }, items.map((item, i) => (React.createElement("div", { key: i, className: `inline-flex flex-col items-center justify-center rounded-xl py-2 px-3 border min-w-[80px] ${status === 'over' ? 'bg-emerald-50/20 border-emerald-100/50' : 'bg-slate-50/50 border-slate-200'}` },
                        React.createElement("span", { className: "text-2xl font-black text-slate-900 tabular-nums leading-none" }, item.val),
                        React.createElement("span", { className: `text-xs font-bold mt-1 ${status === 'over' ? 'text-emerald-700' : 'text-slate-500'}` },
                            "x",
                            item.count)))))))))),
            React.createElement("div", { className: "space-y-3 pt-4" },
                React.createElement("div", { className: `text-center text-sm font-bold mb-2 ${status === 'over' ? 'text-emerald-700' : 'text-slate-500'}` }, status === 'over' ? t.scenarioOld : t.shortageOld),
                React.createElement("div", { className: "flex flex-wrap gap-2 items-stretch justify-center" }, (status === 'over' ? scenariosOld : shortageScenariosOld).map((items, idx) => (React.createElement("div", { key: `old-${idx}`, className: `flex-auto min-w-[140px] rounded-2xl border bg-white p-4 shadow-sm flex flex-col justify-center ${status === 'over' ? 'border-emerald-100' : 'border-slate-100'}` },
                    React.createElement("div", { className: "mb-2 flex items-center gap-2 justify-center" },
                        React.createElement("span", { className: `px-3 py-1 rounded text-xs font-black uppercase tracking-widest ${status === 'over' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-50 text-slate-500'}` },
                            t.opt,
                            " ",
                            idx + 1)),
                    React.createElement("div", { className: "flex flex-wrap gap-2 justify-center" }, items.map((item, i) => (React.createElement("div", { key: i, className: `inline-flex flex-col items-center justify-center rounded-xl py-2 px-3 border min-w-[80px] ${status === 'over' ? 'bg-emerald-50/20 border-emerald-100/50' : 'bg-slate-50/50 border-slate-200'}` },
                        React.createElement("span", { className: "text-2xl font-black text-slate-900 tabular-nums leading-none" }, item.val),
                        React.createElement("span", { className: `text-xs font-bold mt-1 ${status === 'over' ? 'text-emerald-700' : 'text-slate-500'}` },
                            "x",
                            item.count)))))))))))),
        React.createElement(Footer, { t: t })));
};

export default UnifiedCalculator;

