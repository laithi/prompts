import React, { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } from 'react';
import { IconIdea } from './shared/Icons';
const SmartHints = ({ step, onNext, onSkip, t, isAr }) => {
    const [pos, setPos] = useState(null);
    useEffect(() => { if (step > 0)
        document.body.classList.add('no-scroll');
    else
        document.body.classList.remove('no-scroll'); return () => document.body.classList.remove('no-scroll'); }, [step]);
    useLayoutEffect(() => {
        const calculatePos = () => {
            let targetId = '';
            if (step === 1)
                targetId = 'toggle-container';
            if (step === 2)
                targetId = 'tab-btn-change';
            if (targetId) {
                const el = document.getElementById(targetId);
                if (el) {
                    const rect = el.getBoundingClientRect();
                    setPos({ top: rect.top, left: rect.left, width: rect.width, height: rect.height, bottom: rect.bottom });
                }
            }
            else {
                setPos(null);
            }
        };
        calculatePos();
        window.addEventListener('resize', calculatePos);
        return () => window.removeEventListener('resize', calculatePos);
    }, [step]);
    if (step === 0 || !pos)
        return null;
    const cardStyle = { top: pos.bottom + 25, left: isAr ? 'auto' : Math.min(Math.max(10, pos.left), window.innerWidth - 300), right: isAr ? Math.min(Math.max(10, window.innerWidth - (pos.left + pos.width) - 20), window.innerWidth - 300) : 'auto', width: '280px' };
    if (!isAr)
        cardStyle.left = Math.max(10, Math.min(window.innerWidth - 290, pos.left + (pos.width / 2) - 140));
    if (isAr)
        cardStyle.right = Math.max(10, Math.min(window.innerWidth - 290, (window.innerWidth - pos.left - pos.width) + (pos.width / 2) - 140));
    const arrowLeft = pos.left + (pos.width / 2);
    return (React.createElement("div", { className: "fixed inset-0 z-[100] bg-transparent transition-all duration-300 pointer-events-auto" },
        React.createElement("div", { className: "absolute bg-transparent border-[4px] border-indigo-500 rounded-2xl transition-all duration-300 highlight-pulse pointer-events-none", style: { top: pos.top - 6, left: pos.left - 6, width: pos.width + 12, height: pos.height + 12, boxShadow: '0 0 0 9999px rgba(0,0,0,0)' } }),
        React.createElement("div", { className: "absolute bg-white p-6 rounded-3xl shadow-[0_10px_60px_-15px_rgba(0,0,0,0.3)] animate-fade-in border border-indigo-100 pointer-events-auto", style: cardStyle },
            React.createElement("div", { className: "flex justify-between items-start mb-3" },
                React.createElement("div", { className: "flex items-center gap-3" },
                    step === 1 ? React.createElement(IconIdea, null) : React.createElement("span", { className: "text-2xl" }, "\uD83E\uDD1D"),
                    React.createElement("span", { className: `font-black text-lg ${step === 1 ? 'text-indigo-600' : 'text-blue-600'}` }, step === 1 ? t.hint1Title : t.hint2Title)),
                React.createElement("button", { onClick: onSkip, className: "text-xs font-bold text-slate-400 hover:text-red-500 transition-colors bg-slate-100 px-3 py-1.5 rounded-full" }, t.hintSkip)),
            React.createElement("p", { className: "text-base text-slate-700 font-bold mb-6 leading-relaxed" }, step === 1 ? t.hint1Desc : t.hint2Desc),
            React.createElement("div", { className: "absolute -top-3 w-6 h-6 bg-white rotate-45 border-t border-l border-indigo-100", style: { left: !isAr ? arrowLeft - parseInt(cardStyle.left) - 10 : 'auto', right: isAr ? (window.innerWidth - arrowLeft) - parseInt(cardStyle.right) - 10 : 'auto' } }),
            React.createElement("button", { onClick: onNext, className: `w-full py-3 text-white rounded-2xl font-black text-sm shadow-xl ${step === 1 ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/30' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/30'}` }, step === 2 ? t.hintDone : t.hintNext))));
};

export default SmartHints;

