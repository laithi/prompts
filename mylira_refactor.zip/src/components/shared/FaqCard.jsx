import React, { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } from 'react';
import { IconChevronDown, IconCopy } from './Icons';
const FaqCard = ({ item, t }) => {
    const [copied, setCopied] = useState(false);
    const handleCopy = () => {
        const text = `${item.q}\n${item.a}`;
        navigator.clipboard.writeText(text).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); });
    };
    return (React.createElement("div", { className: "app-card p-5 border border-slate-100 shadow-sm" },
        React.createElement("h4", { className: "font-black text-slate-800 text-lg mb-2 leading-relaxed" }, item.q),
        React.createElement("p", { className: "text-base font-bold text-slate-700 leading-relaxed whitespace-pre-line mb-4" }, item.a),
        React.createElement("button", { onClick: handleCopy, className: `w-full py-2.5 px-4 rounded-xl text-sm font-black flex items-center justify-center gap-2 transition-all ${copied ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'}` }, copied ? React.createElement("span", null, t.copied) : React.createElement(React.Fragment, null,
            React.createElement(IconCopy, null),
            React.createElement("span", null, t.copyQa)))));
};

export default FaqCard;

