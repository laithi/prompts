import React, { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } from 'react';
import { IconInstagram, IconWhatsapp } from './Icons';
const Footer = ({ t }) => (React.createElement("div", { className: "pt-6 border-t border-slate-200 mt-6 text-center pb-8 px-4" },
    React.createElement("h4", { className: "text-sm font-black text-slate-600 mb-4" }, t.contactUs),
    React.createElement("div", { className: "flex justify-center gap-6 mb-6" },
        React.createElement("a", { href: "https://wa.me/963993995261", target: "_blank", rel: "noopener noreferrer", "aria-label": "WhatsApp", className: "p-3 bg-emerald-50 text-emerald-600 rounded-full hover:bg-emerald-100 transition shadow-sm" },
            React.createElement(IconWhatsapp, null)),
        React.createElement("a", { href: "", target: "_blank", rel: "noopener noreferrer", "aria-label": "Instagram", className: "p-3 bg-pink-50 text-pink-600 rounded-full hover:bg-pink-100 transition shadow-sm" },
            React.createElement(IconInstagram, null))),
    React.createElement("p", { className: "text-sm font-black text-slate-500 uppercase tracking-widest" }, t.developedBy)));

export default Footer;

