import React, { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } from 'react';
import { IconTrash } from './shared/Icons';
function ElectricityCalculator({ lang }) {
    const [consumption, setConsumption] = useState('');
    const [consumptionError, setConsumptionError] = useState('');
    const [subscriberType, setSubscriberType] = useState('residential');
    const [isExempt, setIsExempt] = useState(false);

    // Inject required styles (scoped by class names)
    useEffect(() => {
        if (document.getElementById('mylira-electric-css')) return;
        const style = document.createElement('style');
        style.id = 'mylira-electric-css';
        style.textContent = `
            .result-card { background: linear-gradient(135deg, #059669 0%, #10b981 100%); }
            .animate-pop { animation: pop 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
            @keyframes pop { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        `;
        document.head.appendChild(style);
    }, []);

    const convertArabicNumbers = (str) => {
        const dict = { '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9' };
        return (str || '').replace(/[٠-٩]/g, (d) => dict[d]);
    };
    const validateConsumption = (value) => {
        const num = parseFloat(value);
        if (isNaN(num)) return { valid: false, error: lang === 'en' ? 'Invalid number' : 'رقم غير صالح' };
        if (num < 0) return { valid: false, error: lang === 'en' ? 'Cannot be negative' : 'لا يمكن أن يكون سالباً' };
        if (num > 100000) return { valid: false, error: lang === 'en' ? 'Value is too large' : 'القيمة كبيرة جداً' };
        return { valid: true, value: num };
    };


    const handleInputChange = (e) => {
        const val = convertArabicNumbers(e.target.value);
        if (/^\d*\.?\d*$/.test(val)) {
            setConsumption(val);
            const v = validateConsumption(val);
            setConsumptionError(v.valid || val === '' ? '' : v.error);
        }
    };

    // Hide keyboard when swiping down
    useEffect(() => {
        let startY = 0;
        const handleTouchStart = (e) => { startY = e.touches[0].clientY; };
        const handleTouchMove = (e) => {
            const currentY = e.touches[0].clientY;
            if (currentY - startY > 40) {
                try { document.activeElement && document.activeElement.blur && document.activeElement.blur(); } catch (err) {}
            }
        };
        window.addEventListener('touchstart', handleTouchStart, { passive: true });
        window.addEventListener('touchmove', handleTouchMove, { passive: true });
        return () => {
            window.removeEventListener('touchstart', handleTouchStart);
            window.removeEventListener('touchmove', handleTouchMove);
        };
    }, []);

    const quickValues = [100, 200, 300, 400, 500, 1000];

    const subscriberOptions = useMemo(() => ([
        { id: 'residential', label: lang === 'en' ? 'Residential' : 'سكني' },
        { id: 'public', label: lang === 'en' ? 'Public sector' : 'قطاع عام' },
        { id: 'private', label: lang === 'en' ? 'Private sector' : 'قطاع خاص' },
        { id: 'industrial_high', label: lang === 'en' ? 'Industrial (high)' : 'صناعي (استهلاك عالي)' },
        { id: 'agricultural', label: lang === 'en' ? 'Agricultural' : 'زراعي' },
        { id: 'commercial', label: lang === 'en' ? 'Commercial' : 'تجاري' },
        { id: 'tourist', label: lang === 'en' ? 'Tourism' : 'سياحي' },
        { id: 'charity', label: lang === 'en' ? 'Charity' : 'خيري' },
        { id: 'temporary', label: lang === 'en' ? 'Temporary use' : 'استخدام مؤقت' },
        { id: 'advertising', label: lang === 'en' ? 'Advertising administration' : 'إدارة إعلانية' },
    ]), [lang]);

    const calculation = useMemo(() => {
        const v = validateConsumption(consumption);
        const val = v.valid ? v.value : 0;
        let totalOld = 0;
        const slabs = [];

        if (subscriberType === 'residential') {
            if (val <= 300) {
                totalOld = val * 600;
                slabs.push({ range: lang === 'en' ? 'Slab 1 (1-300)' : 'الشريحة الأولى (1-300)', price: 600, cost: totalOld });
            } else {
                const s1 = 300 * 600;
                const s2 = (val - 300) * 1400;
                totalOld = s1 + s2;
                slabs.push({ range: lang === 'en' ? 'Slab 1 (1-300)' : 'الشريحة الأولى (1-300)', price: 600, cost: s1 });
                slabs.push({ range: lang === 'en' ? 'Slab 2 (>300)' : 'الشريحة الثانية (>300)', price: 1400, cost: s2 });
            }
        } else if (subscriberType === 'advertising') {
            const price = isExempt ? 1700 : 1800;
            totalOld = val * price;
            slabs.push({ range: (lang === 'en'
                ? `Advertising (${isExempt ? 'Exempt' : 'Subject'})`
                : `إدارة إعلانية (${isExempt ? 'معفى' : 'خاضع'})`), price, cost: totalOld });
        } else {
            const price = isExempt ? 1700 : 1400;
            totalOld = val * price;
            slabs.push({ range: (lang === 'en'
                ? `Flat tariff (${isExempt ? 'Exempt' : 'Subject'})`
                : `تعرفة ثابتة (${isExempt ? 'معفى' : 'خاضع'})`), price, cost: totalOld });
        }

        return { totalOld, totalNew: totalOld / 100, slabs };
    }, [consumption, subscriberType, isExempt, lang]);

    const share = () => {
        const label = (subscriberOptions.find(o => o.id === subscriberType) || {}).label || subscriberType;
        const text = (lang === 'en')
            ? `📊 Estimated electricity bill:\nCategory: ${label}\nConsumption: ${consumption} kWh\nAmount (old): ${calculation.totalOld.toLocaleString()} SYP\nAmount (new): ${calculation.totalNew.toLocaleString()} (new lira)`
            : `📊 فاتورة الكهرباء التقديرية:\nالفئة: ${label}\nالاستهلاك: ${consumption} kWh\nالمبلغ (قديم): ${calculation.totalOld.toLocaleString()} ل.س\nالمبلغ (جديد): ${calculation.totalNew.toLocaleString()} ليرة`;
        window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
    };

    const blurActive = () => { try { document.activeElement && document.activeElement.blur && document.activeElement.blur(); } catch (err) {} };

    return React.createElement("div", {
        className: "app-container-wrapper p-4 pb-20",
        onClick: blurActive
    },
        // Header
        React.createElement("div", { className: "bg-slate-900 text-white p-7 rounded-[2.5rem] shadow-2xl text-center mb-6 select-none" },
            React.createElement("div", { className: "inline-block bg-blue-500/20 p-3 rounded-2xl mb-3" },
                React.createElement("svg", { className: "text-blue-400", width: "28", height: "28", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3" },
                    React.createElement("path", { d: "M13 2L3 14h9l-1 8 10-12h-9l1-8z" })
                )
            ),
            React.createElement("h1", { className: "text-2xl font-black block" }, lang === 'en' ? "Syrian Electricity Calculator" : "حاسبة الكهرباء السورية"),
            React.createElement("p", { className: "text-slate-400 text-sm font-bold mt-2" }, lang === 'en' ? "Based on old & new Syrian lira" : "بناءً على الليرة السورية الجديدة والقديمة")
        ),

        // Inputs card
        React.createElement("div", {
            className: "bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-200 mb-6",
            onClick: (e) => e.stopPropagation()
        },
            React.createElement("label", { className: "text-slate-500 font-black text-xs block mb-3 mr-2" }, lang === 'en' ? "Consumption (kWh)" : "كمية الاستهلاك (kWh)"),
            React.createElement("input", {
                type: "text",
                inputMode: "decimal",
                value: consumption,
                onChange: handleInputChange,
                onKeyDown: (e) => e.key === 'Enter' && e.target.blur(),
                className: "w-full text-5xl font-black p-4 bg-slate-50 rounded-3xl border-none text-center outline-none focus:ring-4 focus:ring-blue-500/10 transition-all mb-4",
                placeholder: lang === 'en' ? "0" : "٠"
            }),
            (consumptionError ? React.createElement("div", { className: "text-red-600 font-bold text-sm mb-3" }, consumptionError) : null),

            React.createElement("div", { className: "grid grid-cols-3 gap-2 mb-6" },
                ...quickValues.map(v => React.createElement("button", {
                    key: v,
                    onClick: () => { setConsumption(v.toString()); blurActive(); },
                    className: "py-2.5 bg-slate-100 active:bg-slate-800 active:text-white rounded-xl text-sm font-black transition-all"
                }, v))
            ),

            React.createElement("div", { className: "space-y-4" },
                React.createElement("div", null,
                    React.createElement("label", { className: "text-slate-500 font-black text-xs block mb-2 mr-2" }, lang === 'en' ? "Subscriber category" : "فئة الاشتراك"),
                    React.createElement("select", {
                        value: subscriberType,
                        onChange: (e) => setSubscriberType(e.target.value),
                        className: "w-full p-4 bg-slate-100 rounded-2xl border-none font-bold text-lg outline-none appearance-none cursor-pointer"
                    },
                        ...subscriberOptions.map(opt => React.createElement("option", { key: opt.id, value: opt.id }, opt.label))
                    )
                ),

                subscriberType !== 'residential' && React.createElement("div", { className: "animate-pop" },
                    React.createElement("label", { className: "text-slate-500 font-black text-xs block mb-2 mr-2" }, lang === 'en' ? "Electricity system" : "نظام الكهرباء"),
                    React.createElement("div", { className: "flex gap-2 p-1.5 bg-slate-100 rounded-2xl" },
                        React.createElement("button", {
                            onClick: () => setIsExempt(false),
                            className: `flex-1 py-3 rounded-xl font-black text-sm transition-all ${!isExempt ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`
                        }, lang === 'en' ? "Subject to rationing" : "خاضع للتقنين"),
                        React.createElement("button", {
                            onClick: () => setIsExempt(true),
                            className: `flex-1 py-3 rounded-xl font-black text-sm transition-all ${isExempt ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`
                        }, lang === 'en' ? "Exempt (24h)" : "معفى (٢٤ ساعة)")
                    )
                )
            )
        ),

        // Results
        (parseFloat(consumption) > 0) && React.createElement("div", { className: "animate-pop space-y-4 pb-10" },
            React.createElement("div", { className: "result-card text-white p-8 rounded-[3rem] shadow-xl text-center relative" },
                React.createElement("p", { className: "text-emerald-100 text-xs font-black mb-1 opacity-80" }, lang === 'en' ? "Estimated total bill" : "إجمالي الفاتورة التقديرية"),
                React.createElement("div", { className: "text-5xl font-black mb-3" },
                    calculation.totalOld.toLocaleString(), " ",
                    React.createElement("span", { className: "text-lg" }, lang === 'en' ? "SYP" : "ل.س")
                ),
                React.createElement("div", { className: "w-1/2 h-px bg-white/20 mx-auto my-4" }),
                React.createElement("div", { className: "text-2xl font-bold opacity-90" },
                    calculation.totalNew.toLocaleString(), " ",
                    (lang === 'en' ? "new lira" : "ليرة جديدة")
                )
            ),

            React.createElement("div", { className: "bg-white p-6 rounded-[2.5rem] border border-slate-200" },
                React.createElement("h3", { className: "text-slate-400 font-black text-[10px] mb-4 uppercase tracking-widest mr-2" }, lang === 'en' ? "Pricing details" : "تفاصيل التسعير"),
                React.createElement("div", { className: "space-y-3" },
                    ...calculation.slabs.map((s, i) => React.createElement("div", {
                        key: i,
                        className: "flex justify-between items-center p-4 bg-slate-50 rounded-2xl border border-slate-100"
                    },
                        React.createElement("div", null,
                            React.createElement("div", { className: "font-black text-slate-800 text-xs" }, s.range),
                            React.createElement("div", { className: "text-[10px] font-bold text-blue-500 mt-1" },
                                (lang === 'en' ? "kWh price: " : "سعر الكيلو: "),
                                s.price, " ",
                                (lang === 'en' ? "SYP" : "ل.س")
                            )
                        ),
                        React.createElement("div", { className: "font-black text-slate-900" },
                            s.cost.toLocaleString(), " ",
                            React.createElement("span", { className: "text-[10px]" }, lang === 'en' ? "SYP" : "ل.س")
                        )
                    ))
                )
            ),

            React.createElement("button", {
                onClick: share,
                className: "w-full py-5 bg-blue-600 text-white rounded-[2rem] font-black text-lg shadow-lg hover:bg-blue-700 active:scale-95 transition-all flex items-center justify-center gap-3"
            },
                React.createElement("span", null, lang === 'en' ? "Share on WhatsApp" : "مشاركة عبر واتساب"),
                React.createElement("svg", { width: "22", height: "22", viewBox: "0 0 24 24", fill: "currentColor" },
                    React.createElement("path", { d: "M12.031 6.172c-2.202 0-3.991 1.789-3.991 3.991 0 .585.131 1.153.384 1.671l-.514 1.878 1.921-.504c.5.244 1.054.373 1.621.373 2.201 0 3.991-1.789 3.991-3.991s-1.789-3.991-3.991-3.991zm2.393 5.408c-.103.284-.594.543-.819.58-.225.036-.505.061-1.157-.205-.815-.333-1.342-1.154-1.383-1.209-.041-.055-.326-.434-.326-.827 0-.393.205-.586.279-.668.073-.082.161-.103.214-.103s.103 0 .147.001c.046.001.109-.017.171.131.062.148.212.518.231.555.019.037.031.08.006.13-.025.051-.037.082-.074.126-.037.043-.078.097-.111.131-.038.037-.078.077-.034.153.044.076.196.323.421.523.29.259.534.339.609.376.075.037.12.031.164-.02.044-.051.191-.221.242-.297.051-.076.103-.064.171-.037.069.027.436.206.511.244.075.038.125.056.143.087.018.031.018.179-.085.463z" })
                )
            )
        )
    );
}

export default ElectricityCalculator;

