import React, { useState, useEffect, useMemo, useRef, useCallback, useLayoutEffect } from 'react';
import { IconArrowLeft, IconArrowRight, IconChevronDown, IconHand } from './shared/Icons';
import { getScenarios, formatRes } from '../utils/calculations';
import { RATE, DENOMS_NEW_CONVERTER, DENOMS_OLD_CONVERTER, DENOMS_NEW_VALS_ONLY, DENOMS_OLD_VALS_ONLY, DENOMS_NEW_CHANGE, DENOMS_OLD_CHANGE } from '../constants/denoms';
import { CURRENCY_DETAILS } from '../constants/currencies';
import { FAQ_DATA } from '../constants/texts';
import FaqCard from './shared/FaqCard';
import Footer from './shared/Footer';
const SmartConverter = ({ lang, t, rates }) => {
    const [val, setVal] = useState('');
    const [mode, setMode] = useState('oldToNew');
    const [showMore, setShowMore] = useState(false);
    const [showMoreOptions, setShowMoreOptions] = useState(false);
    const [showAllFaq, setShowAllFaq] = useState(false);
    const [showLegal, setShowLegal] = useState(false);
    const [showTickerHint, setShowTickerHint] = useState(true);
    const tickerRef = useRef(null);
    const animationFrameRef = useRef(null);
    const isAutoScrolling = useRef(true);
    const handleTickerInteraction = () => {
        if (isAutoScrolling.current) {
            isAutoScrolling.current = false;
            setShowTickerHint(false);
            if (animationFrameRef.current)
                cancelAnimationFrame(animationFrameRef.current);
        }
    };
    const handleWheel = (e) => { if (tickerRef.current) {
        tickerRef.current.scrollLeft += e.deltaY;
        handleTickerInteraction();
    } };
    useEffect(() => {
        const scrollContainer = tickerRef.current;
        if (!scrollContainer)
            return;
        const animate = () => {
            if (!isAutoScrolling.current)
                return;
            scrollContainer.scrollLeft += 0.5;
            if (scrollContainer.scrollLeft >= (scrollContainer.scrollWidth - scrollContainer.clientWidth - 1)) {
                scrollContainer.scrollLeft = 0;
            }
            animationFrameRef.current = requestAnimationFrame(animate);
        };
        animationFrameRef.current = requestAnimationFrame(animate);
        return () => { if (animationFrameRef.current)
            cancelAnimationFrame(animationFrameRef.current); };
    }, []);
    const inputRef = useRef(null);
    const isAr = lang === 'ar';
    const toggleMode = (newMode) => { if (newMode !== mode) {
        setMode(newMode);
        setVal('');
        setShowMoreOptions(false);
        if (inputRef.current)
            inputRef.current.focus();
    } };
    const cleanInput = (txt) => { const normalized = txt.replace(/[٠-٩]/g, d => "0123456789"["٠١٢٣٤٥٦٧٨٩".indexOf(d)] || d); return normalized.replace(/[^0-9.]/g, ''); };
    const num = parseFloat(cleanInput(val)) || 0;
    const convertedVal = mode === 'oldToNew' ? (num / RATE) : (num * RATE);
    const baseForCurrency = mode === 'oldToNew' ? convertedVal : convertedVal;
    const formatRes = (val) => { if (!val || isNaN(val) || val === 0)
        return "0"; return val.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 }); };
    const breakdown = useMemo(() => {
        let current = convertedVal;
        const denoms = mode === 'oldToNew' ? DENOMS_NEW_CONVERTER : DENOMS_OLD_CONVERTER;
        const res = [];
        if (current > 0) {
            denoms.forEach(d => {
                const count = Math.floor(current / d.v);
                if (count > 0) {
                    res.push({ ...d, count });
                    current = Math.round((current - count * d.v) * 100) / 100;
                }
            });
        }
        return { list: res, rem: current };
    }, [num, mode, convertedVal]);
    const alternativeScenarios = useMemo(() => {
        if (breakdown.list.length === 0)
            return [];
        const denomsVals = mode === 'oldToNew' ? DENOMS_NEW_VALS_ONLY : DENOMS_OLD_VALS_ONLY;
        const distributedAmount = breakdown.list.reduce((acc, item) => acc + (item.v * item.count), 0);
        if (distributedAmount <= 0)
            return [];
        const allScenarios = getScenarios(distributedAmount, denomsVals, 6);
        const option1Str = JSON.stringify(breakdown.list.map(i => ({ val: i.v, count: i.count })).sort((a, b) => b.val - a.val));
        return allScenarios.filter(scen => {
            const scenStr = JSON.stringify(scen.map(i => ({ val: i.val, count: i.count })).sort((a, b) => b.val - a.val));
            return scenStr !== option1Str;
        });
    }, [breakdown, mode]);
    const tickerItems = [...PRIMARY_CODES, ...SECONDARY_CODES].map(code => {
        var _a, _b, _c, _d;
        const rateBuy = ((_a = rates[code]) === null || _a === void 0 ? void 0 : _a.buy) || ((_b = rates[code]) === null || _b === void 0 ? void 0 : _b.mid);
        const rateSell = ((_c = rates[code]) === null || _c === void 0 ? void 0 : _c.sell) || ((_d = rates[code]) === null || _d === void 0 ? void 0 : _d.mid);
        return { code, flag: FLAG_BY_CODE[code], buy: rateBuy, sell: rateSell };
    }).filter(i => i.buy);
    return (React.createElement("div", { className: "app-container-wrapper" },
        React.createElement("div", { id: "toggle-container", className: "bg-slate-200/80 p-1.5 rounded-2xl mx-1 relative z-20 flex font-black text-sm mt-4" },
            React.createElement("button", { onClick: () => toggleMode('oldToNew'), className: `flex-1 py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all duration-300 ${mode === 'oldToNew' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}` },
                isAr ? React.createElement(IconArrowLeft, null) : React.createElement(IconArrowRight, null),
                React.createElement("span", null, t.toggleOldToNew)),
            React.createElement("button", { onClick: () => toggleMode('newToOld'), className: `flex-1 py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all duration-300 ${mode === 'newToOld' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}` },
                isAr ? React.createElement(IconArrowLeft, null) : React.createElement(IconArrowRight, null),
                React.createElement("span", null, t.toggleNewToOld))),
        React.createElement("div", { className: "app-card p-6 shadow-sm border border-black/5 relative z-0 mx-4 mt-4" },
            React.createElement("div", { className: "text-base font-black text-slate-600 uppercase mb-2 tracking-widest" }, t.inputLabel(mode)),
            React.createElement("input", { ref: inputRef, type: "text", dir: "ltr", inputMode: "decimal", value: val, onChange: (e) => { setVal(cleanInput(e.target.value)); setShowMoreOptions(false); }, onKeyDown: (e) => e.key === 'Enter' && e.target.blur(), placeholder: t.placeholder, className: `input-field text-indigo-950 ${isAr ? 'text-right' : 'text-left'}` }),
            React.createElement("div", { className: "mt-6 pt-5 border-t border-black/5" },
                React.createElement("div", { className: "text-base font-black text-slate-600 uppercase mb-2 tracking-widest" }, t.resultLabel(mode)),
                React.createElement("div", { className: "text-5xl font-black text-indigo-600" }, convertedVal.toLocaleString(isAr ? 'ar-SY' : 'en-US', { maximumFractionDigits: 2 })))),
        breakdown.rem > 0 && (React.createElement("div", { className: "mx-4 mt-4 p-4 bg-amber-50 rounded-2xl border border-amber-100 flex gap-3 items-start animate-pulse" },
            React.createElement("span", { className: "text-2xl" }, "\u26A0\uFE0F"),
            React.createElement("div", { className: "text-amber-900 text-sm font-bold leading-relaxed" }, mode === 'oldToNew' ? t.leftoverMsg(breakdown.rem, Math.round(breakdown.rem * RATE).toLocaleString()) : t.leftoverMsgOld(breakdown.rem, (breakdown.rem / RATE).toFixed(2))))),
        React.createElement("div", { className: "space-y-3 px-4 mt-4" },
            React.createElement("h3", { className: "text-sm font-black text-slate-600 px-2 uppercase tracking-widest" }, t.breakdownTitle),
            React.createElement("div", { className: "space-y-2" }, breakdown.list.length > 0 ? breakdown.list.map(b => (React.createElement("div", { key: b.v, className: "app-card p-4 flex items-center justify-between border border-black/5 shadow-sm" },
                React.createElement("div", { className: "flex items-center gap-4" },
                    React.createElement("span", { className: "text-4xl" }, b.s),
                    React.createElement("div", null,
                        React.createElement("div", { className: "font-black text-2xl leading-none text-slate-800" }, b.v.toLocaleString()),
                        React.createElement("div", { className: "text-sm font-bold text-slate-500 mt-1" }, b.n[lang]))),
                React.createElement("div", { className: "app-button px-5 py-2 rounded-xl font-black text-xl" },
                    "\u00D7 ",
                    b.count)))) : (React.createElement("div", { className: "text-center py-6 text-slate-500 font-bold text-base italic opacity-80" }, t.emptyBreakdown)))),
        alternativeScenarios.length > 0 && (React.createElement("div", { className: "pt-2 px-4" },
            React.createElement("button", { onClick: () => setShowMoreOptions(!showMoreOptions), className: "w-full py-3.5 rounded-2xl bg-indigo-50 text-indigo-700 border border-indigo-100 font-black text-sm flex items-center justify-center gap-2 hover:bg-indigo-100 transition-colors mb-2" },
                React.createElement("span", null, showMoreOptions ? t.hideOptions : t.showOptions),
                React.createElement("span", { className: `transform transition-transform duration-300 ${showMoreOptions ? 'rotate-180' : ''}` },
                    React.createElement(IconChevronDown, null))),
            React.createElement("div", { className: `slider-content ${showMoreOptions ? 'open' : ''}` },
                React.createElement("div", { className: "space-y-3 pb-2" },
                    React.createElement("div", { className: "flex flex-wrap gap-2 items-stretch justify-center" }, alternativeScenarios.map((items, idx) => (React.createElement("div", { key: `alt-${idx}`, className: "flex-auto min-w-[140px] rounded-2xl border bg-white p-4 shadow-sm flex flex-col justify-center border-indigo-100" },
                        React.createElement("div", { className: "mb-2 flex items-center gap-2 justify-center" },
                            React.createElement("span", { className: "px-3 py-1 rounded text-xs font-black uppercase tracking-widest bg-indigo-50 text-indigo-700" },
                                t.opt,
                                " ",
                                idx + 2)),
                        React.createElement("div", { className: "flex flex-wrap gap-2 justify-center" }, items.map((item, i) => (React.createElement("div", { key: i, className: "inline-flex flex-col items-center justify-center bg-slate-50 rounded-xl py-2 px-3 border border-slate-100 min-w-[70px]" },
                            React.createElement("span", { className: "text-2xl font-black text-slate-900 tabular-nums leading-none" }, item.val),
                            React.createElement("span", { className: "text-xs font-bold mt-1 text-indigo-700" },
                                "x",
                                item.count))))))))))))),
        React.createElement("div", { className: "space-y-3 px-4 mt-4" },
            React.createElement("div", { className: "w-full bg-amber-50 border-y border-amber-100 py-2 overflow-hidden mb-2 rounded-xl" },
                React.createElement("div", { className: "animate-marquee inline-block whitespace-nowrap" },
                    React.createElement("span", { className: "text-xs font-bold text-amber-700 px-4" }, t.disclaimer))),
            React.createElement("div", { className: "flex items-center gap-2 pl-2 overflow-hidden" },
                React.createElement("h3", { className: "text-sm font-black text-slate-600 uppercase tracking-widest whitespace-nowrap" }, t.fxTitle),
                React.createElement("div", { className: "relative flex-1 overflow-hidden h-14" },
                    React.createElement("div", { ref: tickerRef, className: "flex overflow-x-auto whitespace-nowrap gap-3 custom-scrollbar h-full items-center px-1", onTouchStart: handleTickerInteraction, onMouseDown: handleTickerInteraction, onWheel: handleWheel }, tickerItems.map(item => {
                        var _a, _b;
                        return (React.createElement("div", { key: item.code, className: "flex-shrink-0 bg-white border border-slate-200 rounded-xl px-4 py-2 flex items-center gap-3 shadow-sm h-full" },
                            React.createElement("span", { className: "text-2xl" }, item.flag),
                            React.createElement("span", { className: "text-base font-black text-slate-800" }, item.code),
                            React.createElement("div", { className: "flex items-center gap-2 text-sm font-mono font-bold" },
                                React.createElement("span", { className: "text-indigo-700" }, (_a = item.buy) === null || _a === void 0 ? void 0 : _a.toFixed(0)),
                                React.createElement("span", { className: "text-slate-400" }, "/"),
                                React.createElement("span", { className: "text-indigo-500" }, (_b = item.sell) === null || _b === void 0 ? void 0 : _b.toFixed(0)))));
                    })),
                    showTickerHint && (React.createElement("div", { className: "absolute inset-0 bg-white/10 backdrop-blur-[1px] flex items-center justify-center pointer-events-none transition-opacity duration-500" },
                        React.createElement("div", { className: "animate-swipe text-slate-800 drop-shadow-md" },
                            React.createElement(IconHand, null)))))),
            React.createElement("div", { className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-3" }, PRIMARY_CODES.map(code => {
                var _a, _b, _c, _d;
                const rateBuy = ((_a = rates[code]) === null || _a === void 0 ? void 0 : _a.buy) || ((_b = rates[code]) === null || _b === void 0 ? void 0 : _b.mid);
                const rateSell = ((_c = rates[code]) === null || _c === void 0 ? void 0 : _c.sell) || ((_d = rates[code]) === null || _d === void 0 ? void 0 : _d.mid);
                const resBuy = (rateBuy && baseForCurrency > 0) ? formatRes(baseForCurrency * rateBuy) : "0";
                const resSell = (rateSell && baseForCurrency > 0) ? formatRes(baseForCurrency * rateSell) : "0";
                const buyClass = resBuy.length > 7 ? "animate-scroll-number" : "";
                const sellClass = resSell.length > 7 ? "animate-scroll-number" : "";
                return (React.createElement("div", { key: code, className: "app-card p-4 flex flex-col justify-center border border-black/5 shadow-sm" },
                    React.createElement("div", { className: "flex justify-between items-start mb-2" },
                        React.createElement("span", { className: "text-3xl filter drop-shadow-sm" }, FLAG_BY_CODE[code]),
                        React.createElement("div", { className: "flex flex-col items-end" },
                            React.createElement("span", { className: "text-base font-black text-slate-800 leading-none" }, code),
                            React.createElement("span", { className: "text-[10px] font-bold text-slate-400 mt-0.5" }, CURRENCY_DETAILS[code][lang]))),
                    React.createElement("div", { className: "flex flex-col gap-1 w-full bg-slate-50 rounded-xl p-2 border border-slate-100" },
                        React.createElement("div", { className: "flex justify-between items-center overflow-hidden" },
                            React.createElement("span", { className: "text-[10px] font-bold text-slate-400 whitespace-nowrap ml-1" }, t.buyLbl),
                            React.createElement("div", { className: "overflow-hidden w-full text-left dir-ltr" },
                                React.createElement("span", { className: `text-sm font-black text-indigo-700 font-mono ${buyClass}` }, resBuy))),
                        React.createElement("div", { className: "w-full h-px bg-slate-200" }),
                        React.createElement("div", { className: "flex justify-between items-center overflow-hidden" },
                            React.createElement("span", { className: "text-[10px] font-bold text-slate-400 whitespace-nowrap ml-1" }, t.sellLbl),
                            React.createElement("div", { className: "overflow-hidden w-full text-left dir-ltr" },
                                React.createElement("span", { className: `text-sm font-black text-emerald-600 font-mono ${sellClass}` }, resSell))))));
            })),
            React.createElement("div", { className: `slider-content ${showMore ? 'open' : ''}` },
                React.createElement("div", { className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4" }, SECONDARY_CODES.map(code => {
                    var _a, _b, _c, _d;
                    const rateBuy = ((_a = rates[code]) === null || _a === void 0 ? void 0 : _a.buy) || ((_b = rates[code]) === null || _b === void 0 ? void 0 : _b.mid);
                    const rateSell = ((_c = rates[code]) === null || _c === void 0 ? void 0 : _c.sell) || ((_d = rates[code]) === null || _d === void 0 ? void 0 : _d.mid);
                    const resBuy = (rateBuy && baseForCurrency > 0) ? formatRes(baseForCurrency * rateBuy) : "0";
                    const resSell = (rateSell && baseForCurrency > 0) ? formatRes(baseForCurrency * rateSell) : "0";
                    const buyClass = resBuy.length > 7 ? "animate-scroll-number" : "";
                    const sellClass = resSell.length > 7 ? "animate-scroll-number" : "";
                    return (React.createElement("div", { key: code, className: "app-card p-4 flex flex-col justify-center border border-black/5 shadow-sm" },
                        React.createElement("div", { className: "flex justify-between items-start mb-2" },
                            React.createElement("span", { className: "text-3xl filter drop-shadow-sm" }, FLAG_BY_CODE[code]),
                            React.createElement("div", { className: "flex flex-col items-end" },
                                React.createElement("span", { className: "text-base font-black text-slate-800 leading-none" }, code),
                                React.createElement("span", { className: "text-[10px] font-bold text-slate-400 mt-0.5" }, CURRENCY_DETAILS[code][lang]))),
                        React.createElement("div", { className: "flex flex-col gap-1 w-full bg-slate-50 rounded-xl p-2 border border-slate-100" },
                            React.createElement("div", { className: "flex justify-between items-center overflow-hidden" },
                                React.createElement("span", { className: "text-[10px] font-bold text-slate-400 whitespace-nowrap ml-1" }, t.buyLbl),
                                React.createElement("div", { className: "overflow-hidden w-full text-left dir-ltr" },
                                    React.createElement("span", { className: `text-sm font-black text-indigo-700 font-mono ${buyClass}` }, resBuy))),
                            React.createElement("div", { className: "w-full h-px bg-slate-200" }),
                            React.createElement("div", { className: "flex justify-between items-center overflow-hidden" },
                                React.createElement("span", { className: "text-[10px] font-bold text-slate-400 whitespace-nowrap ml-1" }, t.sellLbl),
                                React.createElement("div", { className: "overflow-hidden w-full text-left dir-ltr" },
                                    React.createElement("span", { className: `text-sm font-black text-emerald-600 font-mono ${sellClass}` }, resSell))))));
                }))),
            React.createElement("button", { onClick: () => setShowMore(!showMore), className: "w-full py-3.5 rounded-2xl bg-white border border-slate-200 text-slate-700 font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-50 transition-colors" },
                React.createElement("span", null, showMore ? t.lessCurrencies : t.moreCurrencies),
                React.createElement("span", { className: `transform transition-transform duration-300 ${showMore ? 'rotate-180' : ''}` },
                    React.createElement(IconChevronDown, null)))),
        React.createElement("div", { className: "px-4 mt-4" },
            React.createElement("button", { onClick: () => setShowLegal(!showLegal), className: "w-full py-3 rounded-xl bg-amber-50 border border-amber-100 text-amber-700 font-black text-xs flex items-center justify-center gap-2 hover:bg-amber-100 transition-colors shadow-sm" },
                React.createElement("span", null, t.legalTitle),
                React.createElement("span", { className: `transform transition-transform duration-300 ${showLegal ? 'rotate-180' : ''}` },
                    React.createElement(IconChevronDown, null))),
            React.createElement("div", { className: `slider-content ${showLegal ? 'open' : ''}` },
                React.createElement("div", { className: "mt-2 p-4 bg-white rounded-2xl text-right border border-slate-200 shadow-sm" },
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-600 mb-2 font-bold" }, "\u0625\u062E\u0644\u0627\u0621 \u0645\u0633\u0624\u0648\u0644\u064A\u0629 \u0642\u0627\u0646\u0648\u0646\u064A:"),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u062A\u0637\u0628\u064A\u0642 \u00AB\u0644\u064E\u064A\u0652\u0631\u064E\u062A\u064A \u2013 MyLira\u00BB \u0647\u0648 \u0623\u062F\u0627\u0629 \u0645\u0628\u0633\u0651\u0637\u0629 \u0644\u0644\u0645\u0633\u0627\u0639\u062F\u0629 \u0641\u064A \u062A\u062D\u0648\u064A\u0644 \u0627\u0644\u0642\u064A\u0645 \u0628\u064A\u0646 \u0627\u0644\u0644\u064A\u0631\u0629 \u0627\u0644\u0633\u0648\u0631\u064A\u0629 \u0627\u0644\u0642\u062F\u064A\u0645\u0629 \u0648\u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0648\u062A\u0633\u0647\u064A\u0644 \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A \u0627\u0644\u064A\u0648\u0645\u064A\u0629 \u0641\u0642\u0637\u060C \u0648\u0644\u0627 \u064A\u064F\u0639\u062F \u0645\u0631\u062C\u0639\u0627\u064B \u0631\u0633\u0645\u064A\u0627\u064B \u0644\u0623\u064A \u062C\u0647\u0629 \u062D\u0643\u0648\u0645\u064A\u0629 \u0623\u0648 \u0645\u0635\u0631\u0641\u064A\u0629."),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0635\u0631\u0641 \u0627\u0644\u0638\u0627\u0647\u0631\u0629 (\u0625\u0646 \u0648\u064F\u062C\u062F\u062A) \u0647\u064A \u0642\u064A\u0645 \u062A\u0642\u062F\u064A\u0631\u064A\u0629 \u0644\u063A\u0627\u064A\u0627\u062A \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0639\u0627\u0645\u0629 \u0641\u0642\u0637\u060C \u0648\u062A\u064F\u062C\u0644\u0628 \u0622\u0644\u064A\u0627\u064B \u0645\u0646 \u0645\u0635\u0627\u062F\u0631 \u062E\u0627\u0631\u062C\u064A\u0629\u060C \u0648\u0644\u0627 \u062A\u0639\u0628\u0651\u0631 \u0628\u0627\u0644\u0636\u0631\u0648\u0631\u0629 \u0639\u0646 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0631\u0633\u0645\u064A\u0629 \u0627\u0644\u0635\u0627\u062F\u0631\u0629 \u0639\u0646 \u0645\u0635\u0631\u0641 \u0633\u0648\u0631\u064A\u0629 \u0627\u0644\u0645\u0631\u0643\u0632\u064A \u0623\u0648 \u0623\u064A \u062C\u0647\u0629 \u0645\u0639\u062A\u0645\u062F\u0629\u060C \u0648\u0644\u0627 \u064A\u064F\u0636\u0645\u0646 \u062F\u0642\u062A\u0647\u0627 \u0623\u0648 \u062A\u0648\u0642\u064A\u062A \u062A\u062D\u062F\u064A\u062B\u0647\u0627."),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u0644\u0627 \u064A\u064F\u0634\u0643\u0651\u0644 \u0623\u064A \u0645\u062D\u062A\u0648\u0649 \u0645\u0627\u0644\u064A \u0623\u0648 \u0633\u0639\u0631\u064A \u0636\u0645\u0646 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639 \u0646\u0635\u064A\u062D\u0629 \u0627\u0633\u062A\u062B\u0645\u0627\u0631\u064A\u0629 \u0623\u0648 \u0645\u0627\u0644\u064A\u0629 \u0623\u0648 \u0645\u0635\u0631\u0641\u064A\u0629\u060C \u0648\u0644\u0627 \u064A\u062C\u0628 \u0627\u0644\u0627\u0639\u062A\u0645\u0627\u062F \u0639\u0644\u064A\u0647 \u0645\u0646\u0641\u0631\u062F\u0627\u064B \u0644\u0627\u062A\u062E\u0627\u0630 \u0642\u0631\u0627\u0631\u0627\u062A \u0634\u0631\u0627\u0621 \u0623\u0648 \u0628\u064A\u0639 \u0623\u0648 \u062A\u062D\u0648\u064A\u0644 \u0623\u0645\u0648\u0627\u0644."),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u064A\u064F\u0646\u0635\u064E\u062D \u062F\u0627\u0626\u0645\u0627\u064B \u0628\u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u062C\u0647\u0627\u062A \u0627\u0644\u0631\u0633\u0645\u064A\u0629 (\u0645\u0635\u0631\u0641 \u0633\u0648\u0631\u064A\u0629 \u0627\u0644\u0645\u0631\u0643\u0632\u064A\u060C \u0627\u0644\u0645\u0635\u0627\u0631\u0641 \u0627\u0644\u0645\u0631\u062E\u0651\u064E\u0635\u0629\u060C \u0634\u0631\u0643\u0627\u062A \u0627\u0644\u0635\u0631\u0627\u0641\u0629 \u0627\u0644\u0646\u0638\u0627\u0645\u064A\u0629) \u0642\u0628\u0644 \u0627\u0644\u0642\u064A\u0627\u0645 \u0628\u0623\u064A \u0645\u0639\u0627\u0645\u0644\u0629 \u0645\u0627\u0644\u064A\u0629 \u0623\u0648 \u062A\u062C\u0627\u0631\u064A\u0629 \u062A\u0639\u062A\u0645\u062F \u0639\u0644\u0649 \u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0635\u0631\u0641."),
                    React.createElement("p", { className: "text-[11px] leading-relaxed text-slate-500 mb-1" }, "\u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0643 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639\u060C \u0641\u0625\u0646\u0643 \u062A\u0642\u0631\u0651 \u0628\u0623\u0646\u0643 \u062A\u062A\u062D\u0645\u0651\u0644 \u0648\u062D\u062F\u0643 \u0643\u0627\u0645\u0644 \u0627\u0644\u0645\u0633\u0624\u0648\u0644\u064A\u0629 \u0639\u0646 \u0623\u064A \u0642\u0631\u0627\u0631 \u0645\u0627\u0644\u064A \u0623\u0648 \u062A\u062C\u0627\u0631\u064A \u062A\u062A\u062E\u0630\u0647 \u0628\u0646\u0627\u0621\u064B \u0639\u0644\u0649 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629\u060C \u0648\u0623\u0646\u0643 \u062A\u064F\u062E\u0644\u064A \u0645\u0633\u0624\u0648\u0644\u064A\u0629 \u0645\u0627\u0644\u0643 \u0648\u0645\u0637\u0648\u0651\u0631 \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0645\u0646 \u0623\u064A \u0623\u0636\u0631\u0627\u0631 \u0623\u0648 \u062E\u0633\u0627\u0626\u0631 \u0645\u0628\u0627\u0634\u0631\u0629 \u0623\u0648 \u063A\u064A\u0631 \u0645\u0628\u0627\u0634\u0631\u0629 \u0646\u0627\u062A\u062C\u0629 \u0639\u0646 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0647 \u0623\u0648 \u0639\u0646 \u0623\u064A \u062E\u0637\u0623 \u0623\u0648 \u0627\u0646\u0642\u0637\u0627\u0639 \u0641\u064A \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A."),
                    React.createElement("button", { onClick: () => setShowLegal(false), className: "mt-2 text-xs font-bold text-indigo-600 hover:text-indigo-800" }, t.closeLegal)))),
        React.createElement("div", { className: "space-y-4 pt-4 border-t border-black/5 pb-10 px-4 mt-6" },
            React.createElement("h3", { className: "text-base font-black text-slate-600 px-2 uppercase tracking-widest" }, t.faqTitle),
            FAQ_DATA.slice(0, 2).map((item, index) => (React.createElement(FaqCard, { key: index, item: item, t: t }))),
            React.createElement("div", { className: `slider-content ${showAllFaq ? 'open' : ''}` },
                React.createElement("div", { className: "space-y-4 pt-1" }, FAQ_DATA.slice(2).map((item, index) => (React.createElement(FaqCard, { key: index + 2, item: item, t: t }))))),
            React.createElement("button", { onClick: () => setShowAllFaq(!showAllFaq), className: "w-full py-3.5 rounded-2xl bg-white border border-slate-200 text-slate-700 font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-50 transition-colors" },
                React.createElement("span", null, showAllFaq ? t.lessFaq : t.moreFaq),
                React.createElement("span", { className: `transform transition-transform duration-300 ${showAllFaq ? 'rotate-180' : ''}` },
                    React.createElement(IconChevronDown, null)))),
        React.createElement(Footer, { t: t })));
};

export default SmartConverter;

