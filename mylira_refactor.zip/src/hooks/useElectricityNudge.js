import { useEffect, useRef, useState } from 'react';
import { storage } from '../utils/storage';

export function useElectricityNudge(activeTab) {
  const ELEC_NUDGE_MAX_OPENS = 4;
  const [elecOpenCount, setElecOpenCount] = useState(() => {
    const v = parseInt(storage.get('mylira_elec_tab_open_count_v1', '0'), 10);
    return Number.isFinite(v) ? v : 0;
  });

  const showElectricityNudge = elecOpenCount < ELEC_NUDGE_MAX_OPENS;
  const prevTabRef = useRef('converter');

  useEffect(() => {
    if (activeTab === 'electricity' && prevTabRef.current !== 'electricity') {
      setElecOpenCount((prev) => {
        const safePrev = Number.isFinite(prev) ? prev : 0;
        const next = safePrev + 1;
        storage.set('mylira_elec_tab_open_count_v1', String(next));
        return next;
      });
    }
    prevTabRef.current = activeTab;
  }, [activeTab]);

  return { showElectricityNudge, elecOpenCount };
}
