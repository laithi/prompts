import { useEffect, useState } from 'react';
import { storage } from '../utils/storage';

export function useHints() {
  const [hintStep, setHintStep] = useState(0);

  useEffect(() => {
    const hasSeenHints = storage.get('mylira_hints_seen_v28', null);
    if (!hasSeenHints) {
      const t = setTimeout(() => setHintStep(1), 1000);
      return () => clearTimeout(t);
    }
  }, []);

  return { hintStep, setHintStep };
}
