import { useEffect, useState } from 'react';
import { storage } from '../utils/storage';

// Default matches legacy
const DEFAULT_RATES_URL = (import.meta?.env?.VITE_RATES_API)
  || 'https://raw.githubusercontent.com/laithi/lira-telegram-bot/main/rates.json';

export function useRates() {
  const [rates, setRates] = useState(() => storage.getJSON('mylira_rates_data', {}) || {});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        setIsLoading(true);
        const res = await fetch(DEFAULT_RATES_URL, { cache: 'no-store' });
        const data = await res.json();
        if (!cancelled && data?.rates) {
          setRates(data.rates);
          storage.setJSON('mylira_rates_data', data.rates);
        }
      } catch (e) {
        // silent, legacy behavior
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    load();
    return () => { cancelled = true; };
  }, []);

  return { rates, isLoading };
}
