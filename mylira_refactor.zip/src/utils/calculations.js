/* Auto-extracted from legacy app.js */
const getScenarios = (target, denoms, maxCount = 4) => {
    const solutions = [];
    const startTime = performance.now();
    function solve(remaining, idx, currentProfile) {
        if (solutions.length >= maxCount || (performance.now() - startTime > 15))
            return;
        if (remaining === 0) {
            solutions.push(currentProfile);
            return;
        }
        if (idx >= denoms.length)
            return;
        const coin = denoms[idx];
        const maxUse = Math.floor(remaining / coin);
        let countsToTry = [];
        countsToTry.push(maxUse);
        if (maxUse > 0)
            countsToTry.push(maxUse - 1);
        if (maxUse > 1)
            countsToTry.push(0);
        countsToTry = [...new Set(countsToTry)];
        for (let count of countsToTry) {
            if (solutions.length >= maxCount)
                break;
            const newProfile = { ...currentProfile };
            if (count > 0)
                newProfile[coin] = count;
            solve(remaining - (count * coin), idx + 1, newProfile);
        }
    }
    solve(Math.round(target), 0, {});
    return solutions.map(sol => Object.entries(sol).map(([val, count]) => ({ val: parseInt(val), count })).sort((a, b) => b.val - a.val));
};

const formatRes = (val) => { if (!val || isNaN(val) || val === 0)
        return "0"; return val.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 }); };

export { getScenarios, formatRes };