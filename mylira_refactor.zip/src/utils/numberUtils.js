/* Auto-extracted from legacy app.js */
const cleanInput = (txt) => { const normalized = txt.replace(/[٠-٩]/g, d => "0123456789"["٠١٢٣٤٥٦٧٨٩".indexOf(d)] || d); return normalized.replace(/[^0-9.]/g, ''); };

const convertArabicNumbers = (str) => {
        const dict = { '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9' };
        return (str || '').replace(/[٠-٩]/g, (d) => dict[d]);
    };

const parseNumbers = (str) => { const map = { '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9' }; return str.replace(/[٠-٩]/g, (d) => map[d]).replace(/[^0-9.]/g, ''); };


export { cleanInput, convertArabicNumbers, parseNumbers };