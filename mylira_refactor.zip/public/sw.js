/* Enhanced SW: strategies + TTL (safe fallbacks) */
const CACHE_VERSION = 'mylira-v3';
const CACHES = {
  appShell: `${CACHE_VERSION}-app-shell`,
  api: `${CACHE_VERSION}-api`,
  images: `${CACHE_VERSION}-images`,
  fonts: `${CACHE_VERSION}-fonts`,
};

const STRATEGIES = {
  appShell: 'cache-first',
  api: 'network-first',
  images: 'cache-first',
  fonts: 'cache-first',
};

const CACHE_EXPIRY = {
  rates: 1000 * 60 * 60, // 1 hour
  static: 1000 * 60 * 60 * 24 * 7, // 1 week
};

const now = () => Date.now();

async function putWithTimestamp(cache, request, response) {
  // Add a timestamp header for TTL checks (works for non-opaque responses)
  const cloned = response.clone();
  let body;
  try { body = await cloned.blob(); } catch (e) { return cache.put(request, response); }
  const headers = new Headers(cloned.headers);
  headers.set('sw-cache-time', String(now()));
  const wrapped = new Response(body, { status: cloned.status, statusText: cloned.statusText, headers });
  return cache.put(request, wrapped);
}

function isExpired(response, ttlMs) {
  try {
    const t = parseInt(response.headers.get('sw-cache-time') || '0', 10);
    if (!t) return false; // if missing, treat as non-expiring
    return now() - t > ttlMs;
  } catch (e) { return false; }
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHES.appShell);
    await cache.addAll([
      '/',
      '/index.html',
      '/manifest.json',
      '/sw.js',
    ]);
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.map((k) => {
      if (!Object.values(CACHES).includes(k)) return caches.delete(k);
    }));
    self.clients.claim();
  })());
});

function routeFor(request) {
  const url = new URL(request.url);
  if (request.destination === 'image') return 'images';
  if (request.destination === 'font') return 'fonts';
  // Treat GitHub raw rates as API
  if (url.hostname.includes('raw.githubusercontent.com') && url.pathname.endsWith('/rates.json')) return 'api';
  // JSON is API-ish
  if (url.pathname.endsWith('.json')) return 'api';
  // scripts/styles/documents
  if (request.destination === 'script' || request.destination === 'style' || request.mode === 'navigate') return 'appShell';
  return 'appShell';
}

async function cacheFirst(request, cacheName, ttlMs=null) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  if (cached) {
    if (ttlMs && isExpired(cached, ttlMs)) {
      // stale -> try refresh in background
      fetch(request).then((res) => putWithTimestamp(cache, request, res)).catch(() => {});
    }
    return cached;
  }
  const res = await fetch(request);
  await putWithTimestamp(cache, request, res);
  return res;
}

async function networkFirst(request, cacheName, ttlMs=null) {
  const cache = await caches.open(cacheName);
  try {
    const res = await fetch(request);
    await putWithTimestamp(cache, request, res);
    return res;
  } catch (e) {
    const cached = await cache.match(request);
    if (cached) return cached;
    throw e;
  }
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const bucket = routeFor(request);
  const strategy = STRATEGIES[bucket];

  const ttl = (bucket === 'api') ? CACHE_EXPIRY.rates : CACHE_EXPIRY.static;
  const cacheName = CACHES[bucket];

  event.respondWith((async () => {
    if (strategy === 'network-first') return networkFirst(request, cacheName, ttl);
    return cacheFirst(request, cacheName, ttl);
  })());
});
